import React, { useState } from 'react';
import { EmergencyContact, LocationCoordinates } from '../types';
import {
  Users,
  UserPlus,
  Trash2,
  Send,
  Phone,
  PhoneCall,
  ShieldCheck,
  CheckCircle2,
  X,
  MessageSquare,
  MapPin,
  Sparkles,
  AlertOctagon,
  Copy,
  Check
} from 'lucide-react';

interface EmergencyContactsModalProps {
  isOpen: boolean;
  onClose: () => void;
  contacts: EmergencyContact[];
  onAddContact: (contact: Omit<EmergencyContact, 'id'>) => void;
  onDeleteContact: (id: string) => void;
  onTogglePrimary: (id: string) => void;
  userLocation: LocationCoordinates;
  distressTemplate: string;
  onUpdateDistressTemplate: (msg: string) => void;
  onBroadcastDistress: (msgText: string) => void;
}

export const EmergencyContactsModal: React.FC<EmergencyContactsModalProps> = ({
  isOpen,
  onClose,
  contacts,
  onAddContact,
  onDeleteContact,
  onTogglePrimary,
  userLocation,
  distressTemplate,
  onUpdateDistressTemplate,
  onBroadcastDistress,
}) => {
  const [name, setName] = useState('');
  const [relationship, setRelationship] = useState('Friend');
  const [phone, setPhone] = useState('');
  const [isPrimary, setIsPrimary] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [sentLog, setSentLog] = useState<string | null>(null);

  if (!isOpen) return null;

  const getCleanPhone = (phoneNum: string) => phoneNum.replace(/[^0-9]/g, '');

  const getWhatsAppUrl = (phoneNum: string, messageText: string) => {
    let clean = getCleanPhone(phoneNum);
    if (clean.length === 10) {
      clean = '91' + clean;
    }
    return `https://wa.me/${clean}?text=${encodeURIComponent(messageText)}`;
  };

  const getTelUrl = (phoneNum: string) => `tel:${phoneNum.replace(/[^0-9+]/g, '')}`;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;
    onAddContact({
      name: name.trim(),
      relationship,
      phone: phone.trim(),
      isPrimary: isPrimary || contacts.length === 0,
    });
    setName('');
    setPhone('');
    setIsPrimary(false);
  };

  const handleCopyLocationLink = () => {
    const liveLink = `https://safepath.app/track/sf-user-live?lat=${userLocation.lat.toFixed(4)}&lng=${userLocation.lng.toFixed(4)}`;
    navigator.clipboard.writeText(liveLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSendSingleAlert = (contact: EmergencyContact) => {
    const fullMsg = `${distressTemplate}\n\n📍 Live Location: https://safepath.app/track/sf-user-live?lat=${userLocation.lat}&lng=${userLocation.lng}`;
    setSentLog(`Dispatched SMS distress alert to ${contact.name} (${contact.phone})`);
    setTimeout(() => setSentLog(null), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-[#161B22] border border-slate-800 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl text-slate-100 relative">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-white">Emergency Contacts & Guardians</h2>
              <p className="text-xs text-slate-400">Manage your trusted circle for automatic distress broadcasting</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Notification Banner */}
        {sentLog && (
          <div className="mt-4 p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl flex items-center gap-2 text-xs text-emerald-300 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{sentLog}</span>
          </div>
        )}

        {/* Distress Template Editor */}
        <div className="mt-5 bg-slate-900/80 p-4 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
              <span>Distress SMS Message Template</span>
            </label>
            <button
              onClick={handleCopyLocationLink}
              className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 cursor-pointer"
            >
              {copiedLink ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedLink ? 'Link Copied!' : 'Copy Live Location Link'}</span>
            </button>
          </div>
          <textarea
            value={distressTemplate}
            onChange={(e) => onUpdateDistressTemplate(e.target.value)}
            rows={2}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:border-emerald-500 focus:outline-none"
            placeholder="Write default emergency message..."
          />
          <p className="text-[10px] text-slate-500">
            * Coordinates ({userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}) and live map tracking URL are automatically attached during alerts.
          </p>
        </div>

        {/* Existing Contacts List */}
        <div className="mt-6 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">
              Trusted Circle ({contacts.length})
            </h3>
            <button
              onClick={() => onBroadcastDistress(distressTemplate)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-600/30 transition-all cursor-pointer"
            >
              <AlertOctagon className="w-3.5 h-3.5" />
              <span>Broadcast Alert to All</span>
            </button>
          </div>

          {contacts.length === 0 ? (
            <div className="text-center py-6 bg-slate-900/40 rounded-2xl border border-dashed border-slate-800 text-slate-500 text-xs">
              No emergency contacts added yet. Add trusted contacts below.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {contacts.map((c) => (
                <div
                  key={c.id}
                  className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 p-3.5 rounded-2xl flex flex-col justify-between gap-3 shadow-sm"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-bold flex items-center justify-center text-xs shadow-md">
                        {c.name.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-sm text-white">{c.name}</span>
                          {c.isPrimary && (
                            <span className="bg-emerald-500/20 text-emerald-300 text-[9px] font-bold px-1.5 py-0.5 rounded border border-emerald-500/30">
                              PRIMARY
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400">{c.relationship} • {c.phone}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => onDeleteContact(c.id)}
                      className="text-slate-500 hover:text-rose-400 p-1 transition-colors cursor-pointer"
                      title="Remove contact"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex flex-col gap-2 pt-2 border-t border-slate-800">
                    <div className="flex items-center justify-between text-xs">
                      <button
                        onClick={() => onTogglePrimary(c.id)}
                        className="text-[11px] text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                      >
                        {c.isPrimary ? '★ Primary Guardian' : 'Set as Primary'}
                      </button>
                      
                      <button
                        onClick={() => handleSendSingleAlert(c)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 font-semibold text-[11px] transition-colors cursor-pointer border border-indigo-500/30"
                      >
                        <Send className="w-3 h-3" />
                        <span>Log Alert</span>
                      </button>
                    </div>

                    {/* Direct Contact & WhatsApp Alert Dispatch Row */}
                    <div className="grid grid-cols-2 gap-1.5 text-[11px] pt-1">
                      <a
                        href={getTelUrl(c.phone)}
                        className="flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 font-bold transition-all cursor-pointer"
                        title={`Direct phone call to ${c.name} (${c.phone})`}
                      >
                        <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Call Phone</span>
                      </a>

                      <a
                        href={getWhatsAppUrl(
                          c.phone,
                          `${distressTemplate}\n\n📍 Live GPS Location: https://maps.google.com/?q=${userLocation.lat.toFixed(4)},${userLocation.lng.toFixed(4)}`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-green-600/20 hover:bg-green-600/30 text-green-300 border border-green-500/40 font-bold transition-all cursor-pointer"
                        title={`Send direct WhatsApp distress message to ${c.name}`}
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-green-400" />
                        <span>WhatsApp Alert</span>
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Official Emergency Helplines Quick Cards */}
        <div className="bg-[#0A0C10] p-4 rounded-2xl border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
              <span>Official Government Emergency Helplines</span>
            </span>
            <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-md font-semibold">
              24/7 Toll-Free
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
            <a
              href="tel:112"
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-rose-500/30 text-rose-300 flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer font-bold"
            >
              <span className="text-xs text-rose-400">🇮🇳 112</span>
              <span className="text-[10px] text-slate-400 font-normal">All India Emergency</span>
            </a>

            <a
              href="tel:1091"
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-pink-500/30 text-pink-300 flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer font-bold"
            >
              <span className="text-xs text-pink-400">🇮🇳 1091</span>
              <span className="text-[10px] text-slate-400 font-normal">Women Safety</span>
            </a>

            <a
              href="tel:108"
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-500/30 text-amber-300 flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer font-bold"
            >
              <span className="text-xs text-amber-400">🇮🇳 108</span>
              <span className="text-[10px] text-slate-400 font-normal">Medical Ambulance</span>
            </a>

            <a
              href="tel:1930"
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-blue-500/30 text-blue-300 flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer font-bold"
            >
              <span className="text-xs text-blue-400">🇮🇳 1930</span>
              <span className="text-[10px] text-slate-400 font-normal">Cyber Security</span>
            </a>
          </div>
        </div>

        {/* Add New Contact Form */}
        <form onSubmit={handleAdd} className="mt-6 bg-slate-900/90 p-4 rounded-2xl border border-slate-800 space-y-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <UserPlus className="w-3.5 h-3.5 text-emerald-400" />
            <span>Add New Emergency Guardian</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div>
              <label className="text-[10px] text-slate-400 font-medium mb-1 block">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Sarah Jenkins"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-medium mb-1 block">Relationship</label>
              <select
                value={relationship}
                onChange={(e) => setRelationship(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:border-emerald-500 focus:outline-none cursor-pointer"
              >
                <option value="Parent">Parent</option>
                <option value="Partner">Partner</option>
                <option value="Roommate">Roommate</option>
                <option value="Sibling">Sibling</option>
                <option value="Friend">Friend</option>
                <option value="Colleague">Colleague</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-medium mb-1 block">Mobile Phone</label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 (555) 000-0000"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
              <input
                type="checkbox"
                checked={isPrimary}
                onChange={(e) => setIsPrimary(e.target.checked)}
                className="rounded bg-slate-950 border-slate-800 text-emerald-500 focus:ring-0"
              />
              <span>Set as Primary Emergency Guardian</span>
            </label>

            <button
              type="submit"
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl transition-all cursor-pointer shadow-md shadow-emerald-500/20"
            >
              Add Contact
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
