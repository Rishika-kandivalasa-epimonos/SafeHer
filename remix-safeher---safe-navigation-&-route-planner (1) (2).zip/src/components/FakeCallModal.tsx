import React, { useState, useEffect } from 'react';
import { FakeCallPreset } from '../types';
import { FAKE_CALL_PRESETS } from '../data/cityData';
import { startPhoneRingtone, stopPhoneRingtone } from '../utils/audio';
import { Phone, PhoneOff, Mic, MicOff, Volume2, User, X } from 'lucide-react';

interface FakeCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogHistory: (callerName: string) => void;
}

export const FakeCallModal: React.FC<FakeCallModalProps> = ({
  isOpen,
  onClose,
  onLogHistory,
}) => {
  const [selectedPreset, setSelectedPreset] = useState<FakeCallPreset>(FAKE_CALL_PRESETS[0]);
  const [callState, setCallState] = useState<'idle' | 'ringing' | 'active'>('idle');
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    let timer: any = null;
    if (callState === 'active') {
      timer = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [callState]);

  const triggerCall = (preset: FakeCallPreset) => {
    setSelectedPreset(preset);
    setCallState('ringing');
    setCallDuration(0);
    startPhoneRingtone();
  };

  const answerCall = () => {
    stopPhoneRingtone();
    setCallState('active');
    onLogHistory(selectedPreset.callerName);
  };

  const endCall = () => {
    stopPhoneRingtone();
    setCallState('idle');
    setCallDuration(0);
    onClose();
  };

  if (!isOpen) return null;

  const formatDuration = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-md animate-fade-in">
      <div className="bg-[#161B22] border border-slate-800 w-full max-w-sm rounded-3xl shadow-2xl overflow-hidden flex flex-col p-6 text-slate-100 relative">
        
        <button
          onClick={endCall}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {callState === 'idle' ? (
          /* Preset Selection Screen */
          <div className="space-y-4">
            <div className="text-center">
              <h3 className="font-heading font-bold text-lg text-white">Fake Call Companion</h3>
              <p className="text-xs text-slate-400 mt-1">Simulate an incoming phone call to safely deter uncomfortable situations</p>
            </div>

            <div className="space-y-2">
              {FAKE_CALL_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => triggerCall(preset)}
                  className="w-full p-3 rounded-2xl bg-[#0A0C10] border border-slate-800 hover:border-indigo-500/50 text-left transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center font-bold">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white group-hover:text-indigo-400 transition-colors">{preset.callerName}</h4>
                      <p className="text-[11px] text-slate-400">{preset.callerNumber}</p>
                    </div>
                  </div>
                  <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>
        ) : (
          /* Calling / Active Call Screen */
          <div className="flex flex-col items-center justify-between h-[380px] py-4">
            <div className="text-center space-y-2">
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-indigo-600 to-purple-500 border-4 border-slate-800 flex items-center justify-center text-white text-3xl font-bold shadow-xl mx-auto my-2 animate-pulse">
                {selectedPreset.callerName.charAt(0)}
              </div>
              <h3 className="font-heading font-bold text-xl text-white">{selectedPreset.callerName}</h3>
              <p className="text-xs text-slate-400 font-mono">{selectedPreset.callerNumber}</p>
              
              <div className="pt-2">
                {callState === 'ringing' ? (
                  <span className="text-xs font-bold text-amber-400 animate-pulse">Incoming Call...</span>
                ) : (
                  <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                    {formatDuration(callDuration)}
                  </span>
                )}
              </div>
            </div>

            {/* Simulated Voice Script box when active */}
            {callState === 'active' && (
              <div className="bg-[#0A0C10] border border-indigo-500/30 p-3 rounded-2xl text-xs text-slate-300 text-center italic w-full">
                "{selectedPreset.scriptPrompt}"
              </div>
            )}

            {/* Call Action buttons */}
            {callState === 'ringing' ? (
              <div className="flex items-center gap-8">
                <button
                  onClick={endCall}
                  className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg transition-transform active:scale-95 cursor-pointer"
                >
                  <PhoneOff className="w-6 h-6" />
                </button>
                <button
                  onClick={answerCall}
                  className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center shadow-lg transition-transform active:scale-95 cursor-pointer animate-bounce"
                >
                  <Phone className="w-6 h-6" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
                    isMuted ? 'bg-amber-500/20 border-amber-500 text-amber-300' : 'bg-slate-800 border-slate-700 text-slate-300'
                  }`}
                >
                  {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </button>

                <button
                  onClick={endCall}
                  className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg transition-transform active:scale-95 cursor-pointer"
                >
                  <PhoneOff className="w-6 h-6" />
                </button>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
