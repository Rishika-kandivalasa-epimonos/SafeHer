import React, { useState, useEffect } from 'react';
import { GuardianTimer, EmergencyContact } from '../types';
import {
  Clock,
  ShieldCheck,
  AlertOctagon,
  Plus,
  CheckCircle2,
  Bell,
  Send,
  UserCheck
} from 'lucide-react';

interface CheckInTimerCardProps {
  timerState: GuardianTimer;
  onStartTimer: (minutes: number, destination: string, contactId: string) => void;
  onCheckInSafe: () => void;
  onExtendTimer: (extraMinutes: number) => void;
  onCancelTimer: () => void;
  primaryContact?: EmergencyContact;
  contacts: EmergencyContact[];
}

export const CheckInTimerCard: React.FC<CheckInTimerCardProps> = ({
  timerState,
  onStartTimer,
  onCheckInSafe,
  onExtendTimer,
  onCancelTimer,
  primaryContact,
  contacts,
}) => {
  const [minutesInput, setMinutesInput] = useState<number>(15);
  const [destInput, setDestInput] = useState<string>('Home / Apartment');
  const [selectedContactId, setSelectedContactId] = useState<string>('');

  useEffect(() => {
    if (primaryContact && !selectedContactId) {
      setSelectedContactId(primaryContact.id);
    } else if (contacts.length > 0 && !selectedContactId) {
      setSelectedContactId(contacts[0].id);
    }
  }, [primaryContact, contacts, selectedContactId]);

  const formatTime = (totalSeconds: number) => {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleStart = (presetMins?: number) => {
    const mins = presetMins || minutesInput;
    const targetContactName = contacts.find(c => c.id === selectedContactId)?.name || primaryContact?.name || 'All Emergency Guardians';
    onStartTimer(mins, destInput, targetContactName);
  };

  return (
    <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col justify-between relative overflow-hidden group">
      {/* Background glow when active */}
      {timerState.active && (
        <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 via-transparent to-rose-500/10 pointer-events-none animate-pulse" />
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-3 z-10">
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${timerState.active ? 'bg-amber-500 text-slate-950 font-bold animate-bounce' : 'bg-blue-600/20 text-blue-400'}`}>
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-heading font-bold text-sm text-white">Guardian Check-In Timer</h3>
            <p className="text-[11px] text-slate-400">Automated safety check-in countdown</p>
          </div>
        </div>

        {timerState.active ? (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[11px] font-bold">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" /> Active Monitoring
          </span>
        ) : (
          <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider">Ready</span>
        )}
      </div>

      {/* Timer Active View */}
      {timerState.active ? (
        <div className="space-y-4 my-2 z-10 text-center">
          <div className="bg-[#0A0C10] border border-amber-500/40 rounded-2xl p-4">
            <p className="text-[11px] text-slate-400 uppercase tracking-widest font-bold">Time Until Auto-Alert</p>
            <div className="font-heading font-black text-4xl sm:text-5xl text-amber-400 my-1 tracking-tight font-mono">
              {formatTime(timerState.remainingSeconds)}
            </div>
            <div className="text-xs text-slate-300 flex items-center justify-center gap-1.5 mt-1">
              <span>Destination: <strong className="text-white">{timerState.destinationName}</strong></span>
              <span>•</span>
              <span className="text-indigo-300">Notifying: {timerState.contactToNotify}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onCheckInSafe}
              className="w-full py-3 px-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>I Have Arrived (Check In)</span>
            </button>

            <button
              onClick={() => onExtendTimer(5)}
              className="w-full py-3 px-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center justify-center gap-1 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>+5 Mins</span>
            </button>
          </div>

          <button
            onClick={onCancelTimer}
            className="text-xs text-slate-500 hover:text-slate-300 underline cursor-pointer"
          >
            Cancel Timer
          </button>
        </div>
      ) : (
        /* Timer Setup Form */
        <div className="space-y-3 my-1 z-10">
          <div className="grid grid-cols-4 gap-1.5">
            {[5, 15, 30, 45].map((m) => (
              <button
                key={m}
                onClick={() => {
                  setMinutesInput(m);
                  handleStart(m);
                }}
                className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                  minutesInput === m
                    ? 'bg-blue-600 border-blue-500 text-white shadow-md'
                    : 'bg-[#0A0C10] border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                {m}m
              </button>
            ))}
          </div>

          <div className="space-y-2 bg-[#0A0C10] p-3 rounded-2xl border border-slate-800 text-xs">
            <div>
              <label className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block mb-1">Destination Name</label>
              <input
                type="text"
                value={destInput}
                onChange={(e) => setDestInput(e.target.value)}
                placeholder="e.g. Home, Hotel Room, Subway Station"
                className="w-full bg-[#161B22] border border-slate-800 px-3 py-1.5 rounded-xl text-slate-200 focus:outline-none focus:border-blue-500"
              />
            </div>

            {contacts.length > 0 && (
              <div>
                <label className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block mb-1">Guardian to Alert</label>
                <select
                  value={selectedContactId}
                  onChange={(e) => setSelectedContactId(e.target.value)}
                  className="w-full bg-[#161B22] border border-slate-800 px-3 py-1.5 rounded-xl text-slate-200 focus:outline-none focus:border-blue-500 cursor-pointer"
                >
                  {contacts.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.relationship}) {c.isPrimary ? '⭐ Primary' : ''}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <button
            onClick={() => handleStart()}
            className="w-full py-2.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-900/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Start {minutesInput}-Min Guardian Check-In</span>
          </button>
        </div>
      )}

      {/* Footer hint */}
      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-500 z-10">
        <span>SMS Distress alert triggers if timer reaches zero</span>
        <UserCheck className="w-3.5 h-3.5 text-blue-400" />
      </div>
    </div>
  );
};
