import React from 'react';
import { NeighborhoodSafetyProfile } from '../types';
import { BarChart3, ShieldCheck, SunMedium, AlertTriangle, Building2, X } from 'lucide-react';

interface InsightsModalProps {
  isOpen: boolean;
  onClose: () => void;
  neighborhoods: NeighborhoodSafetyProfile[];
}

export const InsightsModal: React.FC<InsightsModalProps> = ({
  isOpen,
  onClose,
  neighborhoods,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-[#161B22] border border-slate-800 w-full max-w-2xl rounded-3xl shadow-2xl p-6 text-slate-100 space-y-4 max-h-[90vh] overflow-y-auto">
        
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-white">Neighborhood Safety Analytics</h2>
              <p className="text-xs text-slate-400">Live safety indices based on lighting, crime data, and verified safe havens</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {neighborhoods.map((n, i) => (
            <div key={i} className="bg-[#0A0C10] border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-base text-white">{n.name}</h3>
                  <p className="text-xs text-slate-400">{n.city} • Safe Hours: <span className="text-teal-400">{n.safeHours}</span></p>
                </div>
                <div className="text-right">
                  <span className="font-heading font-black text-2xl text-emerald-400">{n.overallSafetyIndex}</span>
                  <span className="text-xs text-slate-500 block font-semibold uppercase">Safety Score</span>
                </div>
              </div>

              {/* Index Bars */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-slate-400 flex items-center gap-1">
                      <SunMedium className="w-3.5 h-3.5 text-amber-400" /> Street Lighting Index
                    </span>
                    <span className="text-amber-400 font-bold">{n.lightingIndex}%</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-amber-400 h-full rounded-full" style={{ width: `${n.lightingIndex}%` }} />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-slate-400 flex items-center gap-1">
                      <Building2 className="w-3.5 h-3.5 text-teal-400" /> Monitored Havens
                    </span>
                    <span className="text-teal-400 font-bold">{n.activeHavensCount} Open 24/7</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-teal-400 h-full rounded-full" style={{ width: `${Math.min(n.activeHavensCount * 3, 100)}%` }} />
                  </div>
                </div>
              </div>

              {/* Precautions */}
              <div className="pt-2 border-t border-slate-800/80 text-xs">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mb-1">Pedestrian Safety Tips</span>
                <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                  {n.topPrecautions.map((p, idx) => (
                    <li key={idx}>{p}</li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="pt-2 flex justify-end">
          <button onClick={onClose} className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer">
            Close Insights
          </button>
        </div>

      </div>
    </div>
  );
};
