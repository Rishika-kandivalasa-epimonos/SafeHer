import React, { useState } from 'react';
import { IncidentCategory, LocationCoordinates } from '../types';
import { PlusCircle, AlertTriangle, MapPin, X, CheckCircle2, Sparkles } from 'lucide-react';

interface ReportIncidentModalProps {
  isOpen: boolean;
  onClose: () => void;
  userLocation: LocationCoordinates;
  onSubmitReport: (report: {
    title: string;
    category: IncidentCategory;
    description: string;
    address: string;
  }) => void;
}

export const ReportIncidentModal: React.FC<ReportIncidentModalProps> = ({
  isOpen,
  onClose,
  userLocation,
  onSubmitReport,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<IncidentCategory>('poor_lighting');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('5th St & Howard St Corridor');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsSubmitting(true);
    onSubmitReport({
      title: title.trim(),
      category,
      description: description.trim(),
      address: address.trim(),
    });
    setIsSubmitting(false);
    setTitle('');
    setDescription('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-[#161B22] border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl text-slate-100 relative">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-heading font-bold text-base text-white">Report Safety Hazard</h3>
              <p className="text-[11px] text-slate-400">Alert nearby walkers & update lighting mesh</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-3 text-xs">
          <div>
            <label className="font-bold text-slate-300 block mb-1">Report Title / Issue</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Broken Streetlamp / Unlit Sidewalk"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="font-bold text-slate-300 block mb-1">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as IncidentCategory)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:border-emerald-500 focus:outline-none cursor-pointer"
            >
              <option value="poor_lighting">Poor Lighting / Dark Zone</option>
              <option value="suspicious_activity">Suspicious Activity</option>
              <option value="harassment">Harassment Advisory</option>
              <option value="broken_infrastructure">Broken Infrastructure / Scaffolding</option>
              <option value="police_presence">Active Police / Safety Ambassador Presence</option>
            </select>
          </div>

          <div>
            <label className="font-bold text-slate-300 block mb-1">Approximate Location / Street</label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. 4th & Market St"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="font-bold text-slate-300 block mb-1">Additional Details</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe lighting condition, hazards, or recommended workaround..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all cursor-pointer mt-2"
          >
            Submit Hazard to Community Map
          </button>
        </form>

      </div>
    </div>
  );
};
