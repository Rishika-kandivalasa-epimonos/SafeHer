import React, { useState, useEffect } from 'react';
import {
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Square,
  Sparkles,
  Radio,
  Play,
  Settings2,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  CheckCircle2,
  MessageSquareText
} from 'lucide-react';
import { voiceAI, createSpeechRecognizer, DEFAULT_SPEECH_SETTINGS, SpeechSettings } from '../utils/speechUtils';

interface VoiceAIWidgetProps {
  onSpeechInput?: (text: string) => void;
  onAnnounceRoute?: () => void;
  onAnnounceSafetyStatus?: () => void;
  activeRouteName?: string;
  safetyScore?: number;
}

export const VoiceAIWidget: React.FC<VoiceAIWidgetProps> = ({
  onSpeechInput,
  onAnnounceRoute,
  onAnnounceSafetyStatus,
  activeRouteName = 'Market St Safe Corridor',
  safetyScore = 94,
}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentText, setCurrentText] = useState<string>('');
  const [isListening, setIsListening] = useState(false);
  const [recognizedText, setRecognizedText] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [speechSettings, setSpeechSettings] = useState<SpeechSettings>(DEFAULT_SPEECH_SETTINGS);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    const unsubscribe = voiceAI.subscribe((speaking, text) => {
      setIsSpeaking(speaking);
      if (text) setCurrentText(text);
    });

    setVoices(voiceAI.getAvailableVoices());
    return () => unsubscribe();
  }, []);

  const handleToggleListening = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    const recognizer = createSpeechRecognizer(
      (transcript) => {
        setRecognizedText(transcript);
        if (onSpeechInput) onSpeechInput(transcript);
      },
      () => setIsListening(false),
      (err) => {
        console.warn('Speech rec error:', err);
        setIsListening(false);
      }
    );

    if (recognizer) {
      try {
        setIsListening(true);
        recognizer.start();
      } catch (e) {
        setIsListening(false);
      }
    } else {
      // Fallback simulation for unsupported browsers
      setIsListening(true);
      setTimeout(() => {
        const simulatedText = "Find safest walking path near Market Street";
        setRecognizedText(simulatedText);
        if (onSpeechInput) onSpeechInput(simulatedText);
        setIsListening(false);
        voiceAI.speak(`Received voice prompt: ${simulatedText}. Calculating safe corridor.`);
      }, 2500);
    }
  };

  const handleStopSpeech = () => {
    voiceAI.stop();
  };

  const handleTestVoice = () => {
    voiceAI.speak(
      `SafeHer Guard Voice initialized. Currently monitoring real-time safety indices for ${activeRouteName} with a safety rating of ${safetyScore} percent. All streetlights are active.`,
      speechSettings
    );
  };

  return (
    <div className="bg-[#161B22] border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-xl text-slate-100 flex flex-col gap-3">
      {/* Header Bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-slate-950 font-bold shadow-md shadow-cyan-500/20">
            <Volume2 className={`w-4 h-4 text-white ${isSpeaking ? 'animate-bounce' : ''}`} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-xs text-white">SafeHer Guard Voice Engine</span>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase tracking-widest">
                Hands-Free
              </span>
            </div>
            <p className="text-[10px] text-slate-400">Audio navigation prompts & real-time voice feedback</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-1.5 rounded-lg border text-xs font-semibold transition-all cursor-pointer ${
              showSettings
                ? 'bg-slate-800 border-slate-700 text-white'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Voice AI Settings"
          >
            <Settings2 className="w-3.5 h-3.5" />
          </button>

          {isSpeaking ? (
            <button
              onClick={handleStopSpeech}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold text-xs hover:bg-rose-500/30 transition-all cursor-pointer animate-pulse"
            >
              <Square className="w-3 h-3 fill-rose-300" />
              <span>Stop Voice</span>
            </button>
          ) : (
            <button
              onClick={handleTestVoice}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold text-xs hover:bg-cyan-500/30 transition-all cursor-pointer"
            >
              <Play className="w-3 h-3 fill-cyan-300" />
              <span>Listen Test</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Speech / Listening Animation Status Card */}
      {(isSpeaking || isListening) && (
        <div className="bg-slate-950/80 border border-cyan-500/40 rounded-xl p-2.5 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-0.5 h-4">
              <span className="w-1 bg-cyan-400 h-3 animate-pulse rounded-full" />
              <span className="w-1 bg-cyan-400 h-4 animate-bounce rounded-full" />
              <span className="w-1 bg-cyan-400 h-2 animate-pulse rounded-full" />
              <span className="w-1 bg-cyan-400 h-4 animate-bounce rounded-full" />
            </div>
            <span className="font-semibold text-cyan-300 text-[11px] truncate">
              {isListening
                ? recognizedText
                  ? `Listening: "${recognizedText}"`
                  : 'Listening to your voice command...'
                : `Speaking: "${currentText}"`}
            </span>
          </div>

          <button
            onClick={isSpeaking ? handleStopSpeech : handleToggleListening}
            className="text-[10px] font-bold text-slate-400 hover:text-white underline cursor-pointer shrink-0"
          >
            Cancel
          </button>
        </div>
      )}

      {/* Quick Voice Controls Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        <button
          onClick={handleToggleListening}
          className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border font-bold text-xs transition-all cursor-pointer ${
            isListening
              ? 'bg-rose-600 text-white border-rose-400 shadow-lg shadow-rose-600/30 animate-pulse'
              : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-800'
          }`}
        >
          {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-cyan-400" />}
          <span>{isListening ? 'Listening...' : 'Voice Search'}</span>
        </button>

        {onAnnounceRoute && (
          <button
            onClick={onAnnounceRoute}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 font-bold text-xs transition-all cursor-pointer"
          >
            <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Speak Route</span>
          </button>
        )}

        {onAnnounceSafetyStatus && (
          <button
            onClick={onAnnounceSafetyStatus}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 font-bold text-xs transition-all cursor-pointer col-span-2 sm:col-span-1"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Safety Voice Alert</span>
          </button>
        )}
      </div>

      {/* Expandable Voice Settings */}
      {showSettings && (
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-3 text-xs pt-3">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-300">Speech Rate</span>
            <span className="font-mono text-cyan-400 font-bold">{speechSettings.rate}x</span>
          </div>
          <input
            type="range"
            min="0.7"
            max="1.5"
            step="0.1"
            value={speechSettings.rate}
            onChange={(e) => setSpeechSettings({ ...speechSettings, rate: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 bg-slate-800 rounded-lg cursor-pointer h-1.5"
          />

          <div className="flex items-center justify-between pt-1">
            <span className="font-bold text-slate-300">Voice Pitch</span>
            <span className="font-mono text-cyan-400 font-bold">{speechSettings.pitch}</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="1.5"
            step="0.1"
            value={speechSettings.pitch}
            onChange={(e) => setSpeechSettings({ ...speechSettings, pitch: parseFloat(e.target.value) })}
            className="w-full accent-cyan-500 bg-slate-800 rounded-lg cursor-pointer h-1.5"
          />

          {voices.length > 0 && (
            <div className="pt-1">
              <label className="block text-slate-400 text-[11px] mb-1 font-semibold">Accent / Voice Model</label>
              <select
                value={speechSettings.voiceIndex}
                onChange={(e) => setSpeechSettings({ ...speechSettings, voiceIndex: parseInt(e.target.value, 10) })}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-1.5 text-xs text-slate-200 focus:outline-none"
              >
                {voices.map((v, idx) => (
                  <option key={idx} value={idx}>
                    {v.name} ({v.lang})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
