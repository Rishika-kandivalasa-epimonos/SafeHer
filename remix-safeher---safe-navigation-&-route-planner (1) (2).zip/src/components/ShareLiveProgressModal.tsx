import React, { useState, useEffect } from 'react';
import {
  Share2,
  X,
  Copy,
  Check,
  Send,
  Clock,
  ShieldCheck,
  MapPin,
  Battery,
  UserCheck,
  ExternalLink,
  Lock,
  RefreshCw,
  Trash2,
  Sparkles,
  PhoneCall,
  Eye,
  Radio
} from 'lucide-react';
import { EmergencyContact, SafeRouteOption, UserProfile } from '../types';

interface SharedLinkSession {
  id: string;
  url: string;
  guardianName: string;
  expiresAt: string;
  createdAt: string;
  viewsCount: number;
  active: boolean;
}

interface ShareLiveProgressModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedRoute?: SafeRouteOption | null;
  contacts: EmergencyContact[];
  userProfile?: UserProfile;
  originText: string;
  destinationText: string;
  onSendToast: (msg: string) => void;
}

export const ShareLiveProgressModal: React.FC<ShareLiveProgressModalProps> = ({
  isOpen,
  onClose,
  selectedRoute,
  contacts,
  userProfile,
  originText,
  destinationText,
  onSendToast,
}) => {
  const [selectedGuardianIds, setSelectedGuardianIds] = useState<string[]>(
    contacts.slice(0, 2).map((c) => c.id)
  );
  const [expirationMinutes, setExpirationMinutes] = useState<number>(30);
  const [copiedLink, setCopiedLink] = useState(false);
  const [activeTab, setActiveTab] = useState<'create' | 'active_links' | 'preview'>('create');
  
  // Active Shared Links State
  const [sharedSessions, setSharedSessions] = useState<SharedLinkSession[]>([
    {
      id: 'sess-1',
      url: 'https://safeher.app/live-track/sp-92f1a?guardian=Sarah+Connor',
      guardianName: 'Sarah Connor (Primary)',
      expiresAt: 'In 24 mins',
      createdAt: '10 mins ago',
      viewsCount: 3,
      active: true,
    },
  ]);

  const [generatedLink, setGeneratedLink] = useState<string>('');

  useEffect(() => {
    const token = Math.random().toString(36).substring(2, 9);
    const dest = encodeURIComponent(destinationText || 'Market St');
    setGeneratedLink(`https://safeher.app/track/sp-live-${token}?dest=${dest}&exp=${expirationMinutes}m`);
  }, [destinationText, expirationMinutes, isOpen]);

  if (!isOpen) return null;

  const toggleGuardian = (id: string) => {
    if (selectedGuardianIds.includes(id)) {
      setSelectedGuardianIds(selectedGuardianIds.filter((gId) => gId !== id));
    } else {
      setSelectedGuardianIds([...selectedGuardianIds, id]);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(generatedLink);
    setCopiedLink(true);
    onSendToast('Live tracking link copied to clipboard!');
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCreateAndSendLink = () => {
    const selectedGuardians = contacts.filter((c) => selectedGuardianIds.includes(c.id));
    const guardianNames = selectedGuardians.map((c) => c.name).join(', ') || 'All Guardians';

    const newSession: SharedLinkSession = {
      id: `sess-${Date.now()}`,
      url: generatedLink,
      guardianName: guardianNames,
      expiresAt: `In ${expirationMinutes} mins`,
      createdAt: 'Just now',
      viewsCount: 0,
      active: true,
    };

    setSharedSessions([newSession, ...sharedSessions]);
    onSendToast(`Live progress tracking link sent to ${guardianNames}!`);
    setActiveTab('active_links');
  };

  const handleRevokeSession = (sessionId: string) => {
    setSharedSessions(
      sharedSessions.map((s) => (s.id === sessionId ? { ...s, active: false } : s))
    );
    onSendToast('Tracking link access revoked immediately.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-[#161B22] border border-slate-800 rounded-3xl max-w-xl w-full p-5 sm:p-7 shadow-2xl text-slate-100 relative my-8">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black text-xl shadow-lg shadow-emerald-500/20">
              <Share2 className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Share Live Progress
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Encrypted Temporary URL
                </span>
              </h2>
              <p className="text-xs text-slate-400">Send real-time location & ETA tracking to your trusted guardians</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Sub-Tabs */}
        <div className="flex items-center gap-2 bg-[#0A0C10] p-1.5 rounded-2xl border border-slate-800 mb-5 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('create')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'create'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Create Share Link
          </button>
          
          <button
            onClick={() => setActiveTab('active_links')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'active_links'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Active Links</span>
            <span className="w-4 h-4 rounded-full bg-slate-800 text-emerald-400 text-[10px] font-mono flex items-center justify-center">
              {sharedSessions.filter((s) => s.active).length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'preview'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Guardian View Preview
          </button>
        </div>

        {/* Tab 1: Create & Send Temporary URL */}
        {activeTab === 'create' && (
          <div className="space-y-4 text-xs">
            
            {/* Live Link Output Box */}
            <div className="bg-[#0A0C10] border border-slate-800 rounded-2xl p-4 space-y-2">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                Generated Temporary Tracking Link
              </span>
              <div className="flex items-center gap-2 bg-[#161B22] border border-slate-700/80 rounded-xl px-3 py-2 text-xs">
                <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <input
                  type="text"
                  readOnly
                  value={generatedLink}
                  className="bg-transparent text-emerald-300 font-mono text-xs w-full focus:outline-none"
                />
                <button
                  onClick={handleCopyLink}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shrink-0 cursor-pointer transition-colors"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* Expiration Time Selector */}
            <div className="bg-[#0A0C10] border border-slate-800 rounded-2xl p-4 space-y-2">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" /> Temporary Expiration Duration
              </span>
              <div className="grid grid-cols-4 gap-2 pt-1">
                {[15, 30, 60, 120].map((mins) => (
                  <button
                    key={mins}
                    onClick={() => setExpirationMinutes(mins)}
                    className={`py-2 px-3 rounded-xl border font-bold text-xs transition-all cursor-pointer ${
                      expirationMinutes === mins
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-md'
                        : 'bg-[#161B22] border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mins < 60 ? `${mins} Mins` : `${mins / 60} Hour`}
                  </button>
                ))}
              </div>
            </div>

            {/* Select Trusted Guardians */}
            <div className="bg-[#0A0C10] border border-slate-800 rounded-2xl p-4 space-y-2.5">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block flex items-center justify-between">
                <span>Select Recipients (SMS / In-App Notification)</span>
                <span className="text-emerald-400 font-mono">{selectedGuardianIds.length} Selected</span>
              </span>

              <div className="space-y-2">
                {contacts.map((contact) => {
                  const isSelected = selectedGuardianIds.includes(contact.id);
                  return (
                    <div
                      key={contact.id}
                      onClick={() => toggleGuardian(contact.id)}
                      className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-slate-900 border-emerald-500/50 text-white'
                          : 'bg-[#161B22] border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center font-bold text-xs text-slate-200 border border-slate-700">
                          {contact.name.charAt(0)}
                        </div>
                        <div>
                          <span className="font-bold text-xs block text-slate-200">{contact.name}</span>
                          <span className="text-[10px] text-slate-500">{contact.relationship} • {contact.phone}</span>
                        </div>
                      </div>

                      <div className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                        isSelected ? 'bg-emerald-500 border-emerald-400 text-slate-950' : 'border-slate-700 bg-slate-800'
                      }`}>
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-end gap-2.5 pt-3">
              <button
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <a
                href={`https://wa.me/?text=${encodeURIComponent(`📍 SafeHer Guard Live Route Tracking: ${generatedLink}\n\nI am currently navigating from ${originText || 'Origin'} to ${destinationText || 'Destination'}. Follow my real-time progress!`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-green-600 hover:bg-green-500 text-white font-bold text-xs shadow-lg shadow-green-600/30 transition-all cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>Share via WhatsApp</span>
              </a>

              <button
                onClick={handleCreateAndSendLink}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Send SMS Broadcast</span>
              </button>
            </div>

          </div>
        )}

        {/* Tab 2: Manage Active Links */}
        {activeTab === 'active_links' && (
          <div className="space-y-4 text-xs">
            <p className="text-slate-400 text-xs">
              Manage your active temporary tracking links. Guardians can see your real-time walking path until the link expires or is revoked.
            </p>

            <div className="space-y-3">
              {sharedSessions.map((session) => (
                <div
                  key={session.id}
                  className={`bg-[#0A0C10] border rounded-2xl p-4 space-y-2.5 transition-all ${
                    session.active ? 'border-slate-800' : 'border-slate-800/40 opacity-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`w-2.5 h-2.5 rounded-full ${session.active ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`} />
                      <span className="font-bold text-slate-200 text-xs">{session.guardianName}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                        <Eye className="w-3 h-3 text-cyan-400" /> {session.viewsCount} views
                      </span>
                      {session.active ? (
                        <button
                          onClick={() => handleRevokeSession(session.id)}
                          className="px-2 py-1 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30 font-bold text-[10px] cursor-pointer"
                        >
                          Revoke Link
                        </button>
                      ) : (
                        <span className="text-[10px] font-bold text-rose-400 uppercase">Expired</span>
                      )}
                    </div>
                  </div>

                  <div className="bg-[#161B22] p-2.5 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-300 flex items-center justify-between">
                    <span className="truncate max-w-[280px]">{session.url}</span>
                    <span className="text-[10px] text-amber-400 font-bold">{session.expiresAt}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Guardian View Simulator Preview */}
        {activeTab === 'preview' && (
          <div className="space-y-4 text-xs">
            <div className="bg-gradient-to-br from-slate-900 to-[#0A0C10] border border-cyan-500/30 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="font-bold text-slate-200 text-xs">SafeHer Guard Live View (Mock)</span>
                </div>
                <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Live Telemetry
                </span>
              </div>

              {/* Simulated Mobile Card Guardians See */}
              <div className="bg-[#161B22] border border-slate-800 rounded-xl p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-white text-sm">{userProfile?.name || 'Rishika K'} is walking safe</span>
                    <span className="text-[10px] text-slate-400 block">En route to: {destinationText || 'Market Street Station'}</span>
                  </div>
                  <div className="flex items-center gap-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-1 rounded-lg font-bold text-[11px]">
                    <Battery className="w-3.5 h-3.5" />
                    <span>88% Battery</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] bg-[#0A0C10] p-2.5 rounded-lg border border-slate-800">
                  <div>
                    <span className="text-slate-500 block">Estimated Arrival</span>
                    <span className="font-bold text-emerald-400 text-xs">12 Minutes (8:50 AM)</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Lighting Score</span>
                    <span className="font-bold text-cyan-400 text-xs">{selectedRoute?.lightingScore || 94}% Bright</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> SafeHaven Mesh Monitoring Active
                  </span>
                  <button
                    onClick={() => onSendToast('Simulated: Guardian called Rishika K directly!')}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px] cursor-pointer"
                  >
                    <PhoneCall className="w-3 h-3" />
                    <span>Call User</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
