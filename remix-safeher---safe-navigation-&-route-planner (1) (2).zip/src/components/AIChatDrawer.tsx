import React, { useState } from 'react';
import { Sparkles, Send, X, Bot, User, ShieldAlert, Volume2, Mic, MicOff, Square } from 'lucide-react';
import { voiceAI, createSpeechRecognizer } from '../utils/speechUtils';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

interface AIChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentLocationName: string;
}

export const AIChatDrawer: React.FC<AIChatDrawerProps> = ({
  isOpen,
  onClose,
  currentLocationName,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'ai',
      text: `Hello! I am your SafeHer Guard Companion powered by Gemini 3.6 Flash. I monitor real-time safety indices in ${currentLocationName}. How can I assist your journey tonight?`,
      timestamp: 'Just now',
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSpeakText = (msgId: string, text: string) => {
    if (speakingMsgId === msgId) {
      voiceAI.stop();
      setSpeakingMsgId(null);
      return;
    }

    setSpeakingMsgId(msgId);
    voiceAI.speak(text).then(() => {
      setSpeakingMsgId(null);
    });
  };

  const handleToggleVoiceDictation = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }

    const recognizer = createSpeechRecognizer(
      (transcript) => {
        setInput(transcript);
      },
      () => setIsListening(false),
      () => setIsListening(false)
    );

    if (recognizer) {
      try {
        setIsListening(true);
        recognizer.start();
      } catch (e) {
        setIsListening(false);
      }
    } else {
      setIsListening(true);
      setTimeout(() => {
        const simulatedQuery = "What is the safest path back to Powell Street Station?";
        setInput(simulatedQuery);
        setIsListening(false);
      }, 2000);
    }
  };

  const handleSend = async (textToSend?: string) => {
    const msgText = textToSend || input;
    if (!msgText.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: msgText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/safety-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: msgText,
          contextLocation: currentLocationName,
        }),
      });

      const data = await res.json();
      const aiReplyText = data.reply || 'Stay aware of your surroundings and prefer well-lit main avenues.';
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: aiReplyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, aiMsg]);

      // Automatically speak AI response aloud for hands-free voice companion experience
      handleSpeakText(aiMsg.id, aiReplyText);
    } catch (err) {
      console.error('Error in AI safety chat:', err);
      const fallbackText = 'SafeHer Guard Companion: Always walk on the side of the street facing oncoming traffic, stay near open 24/7 stores, and keep your phone ready for quick SOS.';
      const fallbackMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: fallbackText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
      handleSpeakText(fallbackMsg.id, fallbackText);
    } finally {
      setIsLoading(false);
    }
  };

  const quickPrompts = [
    'What to do if someone is following me?',
    'Where is the nearest 24/7 safe haven?',
    'Is Market Street well-lit right now?',
    'Give me a solo night walking safety checklist',
  ];

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-96 bg-[#161B22] border-l border-slate-800 shadow-2xl flex flex-col animate-slide-in">
      
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-[#0A0C10]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 font-bold flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-heading font-bold text-sm text-white flex items-center gap-1.5">
              SafeHer Guard Voice AI
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
            </h3>
            <p className="text-[10px] text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Gemini 3.6 Flash Voice Engine
            </p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#0A0C10]/40">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex gap-2 text-xs ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {m.sender === 'ai' && (
              <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[82%] p-3 rounded-2xl relative group ${
                m.sender === 'user'
                  ? 'bg-blue-600 text-white rounded-br-none'
                  : 'bg-[#161B22] border border-slate-800 text-slate-200 rounded-bl-none'
              }`}
            >
              <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
              
              <div className="flex items-center justify-between mt-1.5 pt-1 border-t border-slate-800/60">
                <span className="text-[9px] opacity-60">{m.timestamp}</span>

                {m.sender === 'ai' && (
                  <button
                    onClick={() => handleSpeakText(m.id, m.text)}
                    className="flex items-center gap-1 text-[10px] text-emerald-400 hover:text-emerald-300 font-bold cursor-pointer"
                  >
                    {speakingMsgId === m.id ? (
                      <>
                        <Square className="w-3 h-3 fill-emerald-400" />
                        <span>Stop Speech</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Speak AI</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>

            {m.sender === 'user' && (
              <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white shrink-0 mt-0.5 font-bold">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-2 text-xs justify-start">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <Bot className="w-4 h-4 animate-spin-slow" />
            </div>
            <div className="bg-[#161B22] border border-slate-800 p-3 rounded-2xl text-slate-400 italic">
              SafeHer Guard Voice is preparing safety answer...
            </div>
          </div>
        )}
      </div>

      {/* Quick Prompts */}
      <div className="p-2 border-t border-slate-800/80 bg-[#0A0C10] flex gap-1.5 overflow-x-auto text-[11px]">
        {quickPrompts.map((qp, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(qp)}
            className="px-2.5 py-1 rounded-lg bg-[#161B22] hover:bg-slate-800 text-slate-300 border border-slate-800 whitespace-nowrap shrink-0 transition-colors cursor-pointer"
          >
            {qp}
          </button>
        ))}
      </div>

      {/* Input Row with Mic Voice Recognition */}
      <div className="p-3 border-t border-slate-800 bg-[#0A0C10] flex items-center gap-2">
        <button
          onClick={handleToggleVoiceDictation}
          className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
            isListening
              ? 'bg-rose-600 text-white border-rose-400 animate-pulse'
              : 'bg-[#161B22] text-slate-300 border-slate-800 hover:border-emerald-500'
          }`}
          title="Dictate with microphone"
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-emerald-400" />}
        </button>

        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder={isListening ? 'Listening to your voice...' : 'Ask Voice AI safety assistant...'}
          className="flex-1 bg-[#161B22] border border-slate-800 px-3 py-2 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
        />

        <button
          onClick={() => handleSend()}
          disabled={!input.trim()}
          className="p-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold transition-all disabled:opacity-50 cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};

