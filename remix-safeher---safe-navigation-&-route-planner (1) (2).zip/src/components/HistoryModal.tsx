import React, { useState } from 'react';
import { HistoryLogEntry, HistoryType } from '../types';
import {
  History,
  CheckCircle2,
  AlertTriangle,
  Radio,
  PhoneCall,
  Sparkles,
  MapPin,
  Clock,
  Trash2,
  X,
  Filter,
  ShieldCheck,
  Send,
  ExternalLink
} from 'lucide-react';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  historyLogs: HistoryLogEntry[];
  onClearHistory: () => void;
  onSimulateNewCheckIn: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  historyLogs,
  onClearHistory,
  onSimulateNewCheckIn,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filteredLogs = historyLogs.filter((log) => {
    const matchesFilter =
      selectedFilter === 'all' ||
      (selectedFilter === 'check_in' && log.type === 'check_in') ||
      (selectedFilter === 'sos_alert' && (log.type === 'sos_alert' || log.type === 'timer_expired')) ||
      (selectedFilter === 'fake_call' && log.type === 'fake_call') ||
      (selectedFilter === 'ai_audit' && log.type === 'ai_audit') ||
      (selectedFilter === 'incident_report' && log.type === 'incident_report');

    const matchesQuery =
      log.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.locationName && log.locationName.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesFilter && matchesQuery;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-[#161B22] border border-slate-800 w-full max-w-3xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-[#0A0C10]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-white">Safety Activity History</h2>
              <p className="text-xs text-slate-400">Review past check-ins, alert broadcasts, AI audits, and emergency logs</p>
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar & Filters */}
        <div className="p-4 bg-[#0A0C10]/60 border-b border-slate-800 flex flex-col sm:flex-row gap-3 items-center justify-between">
          {/* Search */}
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search logs by keyword or location..."
            className="w-full sm:w-64 bg-[#161B22] border border-slate-800 px-3.5 py-1.5 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />

          {/* Type Filter Pills */}
          <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 text-xs">
            {[
              { id: 'all', label: 'All Logs' },
              { id: 'check_in', label: 'Check-Ins' },
              { id: 'sos_alert', label: 'SOS Alerts' },
              { id: 'fake_call', label: 'Fake Calls' },
              { id: 'ai_audit', label: 'AI Audits' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedFilter(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  selectedFilter === tab.id
                    ? 'bg-blue-600 text-white font-bold shadow-md'
                    : 'bg-[#161B22] text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Logs Timeline Body */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1">
          {filteredLogs.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mx-auto text-slate-500">
                <History className="w-6 h-6" />
              </div>
              <p className="text-sm font-medium text-slate-400">No activity logs found</p>
              <button
                onClick={onSimulateNewCheckIn}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all cursor-pointer"
              >
                Log Test Check-In Now
              </button>
            </div>
          ) : (
            filteredLogs.map((log) => (
              <div
                key={log.id}
                className="bg-[#0A0C10] border border-slate-800 rounded-2xl p-4 hover:border-slate-700 transition-all space-y-2 group"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${getTypeBadgeStyle(log.type)}`}>
                      {getTypeIcon(log.type)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-sm text-white">{log.title}</h4>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${getStatusBadgeStyle(log.status)}`}>
                          {log.status === 'completed' ? 'Success' : log.status === 'alert_sent' ? 'Alert Sent' : log.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1">{log.description}</p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[11px] text-slate-500 flex items-center justify-end gap-1">
                      <Clock className="w-3 h-3 text-slate-500" /> {log.timestamp}
                    </span>
                  </div>
                </div>

                {/* Footer details bar */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <div className="flex items-center gap-1 text-slate-400">
                    <MapPin className="w-3.5 h-3.5 text-blue-400" />
                    <span>{log.locationName || 'GPS Location Verified'}</span>
                  </div>

                  {log.recipientCount && (
                    <span className="text-indigo-400 font-medium">
                      📱 Notified {log.recipientCount} Emergency Contacts
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#0A0C10] border-t border-slate-800 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Total entries: <strong className="text-slate-300">{historyLogs.length}</strong>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onSimulateNewCheckIn}
              className="px-3.5 py-2 rounded-xl bg-blue-600/10 hover:bg-blue-600/20 text-blue-300 border border-blue-500/30 text-xs font-semibold transition-all cursor-pointer"
            >
              + Quick Check-In
            </button>
            <button
              onClick={onClearHistory}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-rose-400 text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

function getTypeIcon(type: HistoryType) {
  switch (type) {
    case 'check_in': return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
    case 'sos_alert':
    case 'timer_expired': return <Radio className="w-4 h-4 text-rose-400" />;
    case 'fake_call': return <PhoneCall className="w-4 h-4 text-indigo-400" />;
    case 'ai_audit': return <Sparkles className="w-4 h-4 text-blue-400" />;
    case 'incident_report': return <AlertTriangle className="w-4 h-4 text-amber-400" />;
    default: return <ShieldCheck className="w-4 h-4 text-emerald-400" />;
  }
}

function getTypeBadgeStyle(type: HistoryType) {
  switch (type) {
    case 'check_in': return 'bg-emerald-500/10 border border-emerald-500/20';
    case 'sos_alert':
    case 'timer_expired': return 'bg-rose-500/10 border border-rose-500/20';
    case 'fake_call': return 'bg-indigo-500/10 border border-indigo-500/20';
    case 'ai_audit': return 'bg-blue-500/10 border border-blue-500/20';
    case 'incident_report': return 'bg-amber-500/10 border border-amber-500/20';
    default: return 'bg-slate-800';
  }
}

function getStatusBadgeStyle(status: string) {
  switch (status) {
    case 'completed': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    case 'alert_sent': return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
    case 'cancelled': return 'bg-slate-800 text-slate-400 border-slate-700';
    default: return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
  }
}
