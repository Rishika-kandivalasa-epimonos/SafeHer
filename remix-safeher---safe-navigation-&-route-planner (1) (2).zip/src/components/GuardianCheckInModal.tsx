import React, { useState } from 'react';
import { EmergencyContact } from '../types';
import {
  Clock,
  ShieldCheck,
  Bell,
  CheckCircle2,
  AlertTriangle,
  X,
  Play,
  RotateCcw,
  Plus,
  MapPin,
  Send,
  Radio
} from 'lucide-react';

interface GuardianCheckInModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTimerSeconds: number | null;
  targetMinutes: number;
  destinationName: string;
  onStartTimer: (minutes: number, destination: string, contactIds: string[]) => void;
  onCancelTimer: () => void;
  onCheckInSuccess: () => void;
  onExtendTimer: (extraMinutes: number) => void;
  contacts: EmergencyContact[];
}

export const GuardianCheckInModal: React.FC<GuardianCheckInModalProps> = ({
  isOpen,
  onClose,
  activeTimerSeconds,
  targetMinutes,
  destinationName,
  onStartTimer,
  onCancelTimer,
  onCheckInSuccess,
  onExtendTimer,
  contacts,
}) => {
  const [minutesInput, setMinutesInput] = useState<number>(10);
  const [destInput, setDestInput] = useState('Home / Residence');
  const [selectedContactIds, setSelectedContactIds] = useState<string[]>(
    contacts.map((c) => c.id)
  );

  if (!isOpen) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleToggleContact = (id: string) => {
    if (selectedContactIds.includes(id)) {
      setSelectedContactIds(selectedContactIds.filter((c) => c !== id));
    } else {
      setSelectedContactIds([...selectedContactIds, id]);
    }
  };

  const isRunning = activeTimerSeconds !== null;
  const progressPercent = isRunning && targetMinutes > 0
    ? Math.max(0, Math.min(100, (activeTimerSeconds / (targetMinutes * 60)) * 100))
    : 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="bg-[#161B22] border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl text-slate-100 relative">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-white">Guardian Safety Check-In</h2>
              <p className="text-xs text-slate-400">Automated countdown alert if you do not check in safely</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Active Timer Display */}
        {isRunning ? (
          <div className="mt-6 space-y-6 text-center">
            
            {/* Live Progress Ring & Digits */}
            <div className="relative w-44 h-44 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-8 border-slate-800" />
              <div
                className="absolute inset-0 rounded-full border-8 border-emerald-500 transition-all duration-1000"
                style={{
                  clipPath: `inset(0 ${100 - progressPercent}% 0 0)`,
                }}
              />
              <div className="z-10 flex flex-col items-center">
                <span className="font-heading font-black text-4xl text-white tracking-wider">
                  {formatTime(activeTimerSeconds!)}
                </span>
                <span className="text-[11px] text-amber-400 font-semibold mt-1 flex items-center gap-1">
                  <Radio className="w-3 h-3 animate-ping" /> Guardian Active
                </span>
              </div>
            </div>

            <div className="bg-slate-900/80 p-3 rounded-2xl border border-slate-800 text-xs text-slate-300">
              <p className="text-slate-400">Target Destination:</p>
              <p className="font-bold text-white text-sm mt-0.5">{destinationName || 'Destination'}</p>
            </div>

            {/* Check-In Actions */}
            <div className="space-y-2">
              <button
                onClick={onCheckInSuccess}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>I Have Safely Arrived! (Check-In)</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => onExtendTimer(5)}
                  className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4 text-amber-400" />
                  <span>+5 Minutes</span>
                </button>

                <button
                  onClick={onCancelTimer}
                  className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-rose-950 text-rose-300 text-xs font-semibold border border-slate-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4 text-rose-400" />
                  <span>Cancel Timer</span>
                </button>
              </div>
            </div>

          </div>
        ) : (
          /* Configure New Timer Form */
          <div className="mt-6 space-y-5">
            
            {/* Destination Input */}
            <div>
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                <span>Destination Name</span>
              </label>
              <input
                type="text"
                value={destInput}
                onChange={(e) => setDestInput(e.target.value)}
                placeholder="e.g. Home, Hotel, Subway Station"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 focus:border-emerald-500 focus:outline-none"
              />
            </div>

            {/* Minutes Duration Preset Grid */}
            <div>
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Expected Travel Duration</span>
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[5, 10, 15, 30].map((mins) => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => setMinutesInput(mins)}
                    className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                      minutesInput === mins
                        ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20'
                        : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {mins} mins
                  </button>
                ))}
              </div>
            </div>

            {/* Select Contacts to Notify */}
            <div>
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1.5 flex items-center gap-1.5">
                <Bell className="w-3.5 h-3.5 text-indigo-400" />
                <span>Notify Contacts If Overdue ({selectedContactIds.length})</span>
              </label>
              
              {contacts.length === 0 ? (
                <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs text-amber-300">
                  Please add emergency contacts first to receive overdue alert notifications.
                </div>
              ) : (
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {contacts.map((c) => {
                    const isChecked = selectedContactIds.includes(c.id);
                    return (
                      <div
                        key={c.id}
                        onClick={() => handleToggleContact(c.id)}
                        className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                          isChecked
                            ? 'bg-indigo-950/40 border-indigo-500/50 text-indigo-200'
                            : 'bg-slate-950/50 border-slate-800/80 text-slate-400'
                        }`}
                      >
                        <div className="flex items-center gap-2 text-xs font-medium">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="rounded bg-slate-900 border-slate-700 text-indigo-500 focus:ring-0"
                          />
                          <span>{c.name} ({c.relationship})</span>
                        </div>
                        <span className="text-[10px] text-slate-500">{c.phone}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Start Timer CTA */}
            <button
              onClick={() => onStartTimer(minutesInput, destInput, selectedContactIds)}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-emerald-500 hover:opacity-95 text-slate-950 font-bold text-xs shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>Start Guardian Check-In ({minutesInput} Mins)</span>
            </button>

          </div>
        )}

      </div>
    </div>
  );
};
