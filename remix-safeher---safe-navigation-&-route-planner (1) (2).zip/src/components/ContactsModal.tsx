import React, { useState } from 'react';
import { EmergencyContact } from '../types';
import {
  Users,
  UserPlus,
  Trash2,
  ShieldCheck,
  Star,
  Phone,
  PhoneCall,
  MessageSquare,
  Send,
  X,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface ContactsModalProps {
  isOpen: boolean;
  onClose: () => void;
  contacts: EmergencyContact[];
  onAddContact: (contact: Omit<EmergencyContact, 'id'>) => void;
  onDeleteContact: (id: string) => void;
  onTogglePrimary: (id: string) => void;
  onTriggerTestAlert: (contact: EmergencyContact) => void;
}

export const ContactsModal: React.FC<ContactsModalProps> = ({
  isOpen,
  onClose,
  contacts,
  onAddContact,
  onDeleteContact,
  onTogglePrimary,
  onTriggerTestAlert,
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [name, setName] = useState('');
  const [relationship, setRelationship] = useState('Family / Parent');
  const [phone, setPhone] = useState('');
  const [isPrimary, setIsPrimary] = useState(false);
  const [sentTestNotice, setSentTestNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    onAddContact({
      name: name.trim(),
      relationship,
      phone: phone.trim(),
      isPrimary: contacts.length === 0 ? true : isPrimary,
    });

    setName('');
    setPhone('');
    setIsPrimary(false);
    setIsAdding(false);
  };

  const handleTest = (contact: EmergencyContact) => {
    onTriggerTestAlert(contact);
    setSentTestNotice(`Simulated alert sent to ${contact.name} (${contact.phone})`);
    setTimeout(() => setSentTestNotice(null), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-[#161B22] border border-slate-800 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-[#0A0C10]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-white">Emergency Contacts & Guardians</h2>
              <p className="text-xs text-slate-400">Trusted circle alerted automatically during SOS or missed check-in timers</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Test Alert Notification Banner */}
        {sentTestNotice && (
          <div className="bg-emerald-950/60 border-b border-emerald-500/30 p-3 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{sentTestNotice}</span>
          </div>
        )}

        {/* Contact List */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1">
          {contacts.length === 0 ? (
            <div className="py-10 text-center space-y-2">
              <p className="text-sm font-medium text-slate-400">No emergency contacts configured yet.</p>
              <p className="text-xs text-slate-500">Add at least one contact to enable live location broadcasts.</p>
            </div>
          ) : (
            contacts.map((c) => (
              <div
                key={c.id}
                className="bg-[#0A0C10] border border-slate-800 hover:border-slate-700 p-4 rounded-2xl flex items-center justify-between gap-3 transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center font-bold text-white text-base shadow-md">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                    {c.isPrimary && (
                      <div className="absolute -top-1 -right-1 w-5 h-5 bg-amber-500 rounded-full flex items-center justify-center text-slate-950 shadow">
                        <Star className="w-3 h-3 fill-slate-950" />
                      </div>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-white">{c.name}</h4>
                      {c.isPrimary && (
                        <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-full font-semibold">
                          Primary Guardian
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                      <span>{c.relationship}</span>
                      <span>•</span>
                      <span className="font-mono text-slate-300">{c.phone}</span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <a
                    href={`tel:${c.phone.replace(/[^0-9+]/g, '')}`}
                    className="p-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title={`Call ${c.name} (${c.phone})`}
                  >
                    <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="hidden sm:inline">Call</span>
                  </a>

                  <a
                    href={`https://wa.me/${c.phone.replace(/[^0-9]/g, '').length === 10 ? '91' + c.phone.replace(/[^0-9]/g, '') : c.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent('EMERGENCY SOS: I need immediate assistance! Check my live location on SafeHer Guard.')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-xl bg-green-600/10 hover:bg-green-600/20 text-green-300 border border-green-500/30 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title={`Send WhatsApp message to ${c.name}`}
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-green-400" />
                    <span className="hidden sm:inline">WhatsApp</span>
                  </a>

                  <button
                    onClick={() => handleTest(c)}
                    className="px-2.5 py-1.5 rounded-xl bg-blue-600/10 hover:bg-blue-600/20 text-blue-300 border border-blue-500/30 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="Send Test Broadcast"
                  >
                    <Send className="w-3 h-3" />
                    <span className="hidden sm:inline">Test Alert</span>
                  </button>

                  <button
                    onClick={() => onTogglePrimary(c.id)}
                    className={`p-2 rounded-xl transition-colors cursor-pointer ${
                      c.isPrimary ? 'bg-amber-500/20 text-amber-400' : 'bg-slate-800 text-slate-400 hover:text-amber-400'
                    }`}
                    title={c.isPrimary ? 'Primary Contact' : 'Set as Primary Guardian'}
                  >
                    <Star className={`w-4 h-4 ${c.isPrimary ? 'fill-amber-400' : ''}`} />
                  </button>

                  <button
                    onClick={() => onDeleteContact(c.id)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                    title="Delete Contact"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}

          {/* Add Contact Form Drawer */}
          {isAdding ? (
            <form onSubmit={handleSubmit} className="bg-[#0A0C10] border border-blue-500/30 p-4 rounded-2xl space-y-3 animate-fade-in mt-3">
              <h4 className="font-bold text-xs uppercase tracking-wider text-blue-400">New Emergency Guardian</h4>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Sarah Connor"
                    className="w-full bg-[#161B22] border border-slate-800 px-3 py-2 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 (555) 019-2834"
                    className="w-full bg-[#161B22] border border-slate-800 px-3 py-2 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Relationship</label>
                  <select
                    value={relationship}
                    onChange={(e) => setRelationship(e.target.value)}
                    className="w-full bg-[#161B22] border border-slate-800 px-3 py-2 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500 cursor-pointer"
                  >
                    <option value="Family / Parent">Family / Parent</option>
                    <option value="Partner / Spouse">Partner / Spouse</option>
                    <option value="Roommate">Roommate</option>
                    <option value="Friend">Friend</option>
                    <option value="Work Security">Work Security</option>
                  </select>
                </div>

                <label className="flex items-center gap-2 mt-4 cursor-pointer text-xs text-slate-300">
                  <input
                    type="checkbox"
                    checked={isPrimary}
                    onChange={(e) => setIsPrimary(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-blue-600 focus:ring-blue-500"
                  />
                  <span>Set as Primary Guardian</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all cursor-pointer shadow-md"
                >
                  Save Guardian
                </button>
              </div>
            </form>
          ) : (
            <button
              onClick={() => setIsAdding(true)}
              className="w-full py-3 border-2 border-dashed border-slate-800 hover:border-blue-500/50 rounded-2xl text-xs font-bold text-slate-400 hover:text-blue-400 flex items-center justify-center gap-2 transition-all cursor-pointer mt-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add Emergency Guardian Contact</span>
            </button>
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 bg-[#0A0C10] border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Contacts stored securely in app session</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all cursor-pointer"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
