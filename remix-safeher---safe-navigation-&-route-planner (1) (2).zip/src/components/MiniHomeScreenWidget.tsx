import React, { useState } from 'react';
import {
  ShieldAlert,
  Radio,
  Clock,
  Mic,
  PhoneCall,
  Sparkles,
  MapPin,
  Building2,
  Minimize2,
  Maximize2,
  Volume2,
  CheckCircle2,
  AlertTriangle,
  Zap,
  Battery,
  ShieldCheck,
  Share2
} from 'lucide-react';
import { voiceAI } from '../utils/speechUtils';

interface MiniHomeScreenWidgetProps {
  onOpenSOS: () => void;
  onOpenFakeCall: () => void;
  onOpenAIChat: () => void;
  onOpenShareProgress?: () => void;
  onQuickStartTimer: (minutes: number) => void;
  onCheckInSafe: () => void;
  activeTimerMinutes: number | null;
  activeRouteName?: string;
  safetyScore?: number;
  nearestHavenName?: string;
  cityName?: string;
}

export const MiniHomeScreenWidget: React.FC<MiniHomeScreenWidgetProps> = ({
  onOpenSOS,
  onOpenFakeCall,
  onOpenAIChat,
  onOpenShareProgress,
  onQuickStartTimer,
  onCheckInSafe,
  activeTimerMinutes,
  activeRouteName = 'Market St Corridor',
  safetyScore = 94,
  nearestHavenName = 'Walgreens 24/7 (200m)',
  cityName = 'San Francisco',
}) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [isVoiceAnnouncing, setIsVoiceAnnouncing] = useState(false);

  const handleQuickAnnounce = () => {
    if (isVoiceAnnouncing) {
      voiceAI.stop();
      setIsVoiceAnnouncing(false);
      return;
    }

    const text = activeTimerMinutes !== null
      ? `Mini Widget Status: Active check-in timer has ${activeTimerMinutes} minutes remaining. Current path is ${activeRouteName} with a safety rating of ${safetyScore} percent.`
      : `Mini Widget Status: SafeHer Guard Mesh active in ${cityName}. Current route ${activeRouteName} is ${safetyScore} percent safe. SafeHaven nearby at ${nearestHavenName}.`;

    setIsVoiceAnnouncing(true);
    voiceAI.speak(text).then(() => {
      setIsVoiceAnnouncing(false);
    });
  };

  if (isMinimized) {
    return (
      <div className="bg-[#161B22]/95 border border-slate-700/80 backdrop-blur-md rounded-2xl p-2.5 shadow-2xl flex items-center justify-between gap-3 transition-all">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setIsMinimized(false)}>
          <div className="w-7 h-7 bg-emerald-500 rounded-lg flex items-center justify-center text-slate-950 shadow-md">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div className="text-xs">
            <span className="font-bold text-white block">SafeHer Mini</span>
            <span className="text-[10px] text-emerald-400">{safetyScore}% Safe • {cityName}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenSOS}
            className="w-7 h-7 bg-rose-600 hover:bg-rose-500 rounded-lg flex items-center justify-center text-white font-bold text-[10px] shadow-sm cursor-pointer"
            title="Emergency SOS"
          >
            SOS
          </button>
          <button
            onClick={() => setIsMinimized(false)}
            className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs cursor-pointer"
            title="Expand Widget"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-[#161B22] via-[#0D1117] to-[#161B22] border-2 border-slate-800 hover:border-slate-700 rounded-3xl p-4 sm:p-5 shadow-2xl transition-all relative group overflow-hidden">
      
      {/* Background Subtle Accent Glow */}
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Widget Header */}
      <div className="flex items-center justify-between mb-3 pb-2.5 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-bold shadow-md shadow-emerald-500/20">
            <Zap className="w-4 h-4 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="font-heading font-bold text-xs text-white uppercase tracking-wider">
                Home Mini Safety Dock
              </h3>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                1-Tap Dock
              </span>
            </div>
            <p className="text-[10px] text-slate-400">Quick access locks & real-time guardian telemetry</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleQuickAnnounce}
            className={`p-1.5 rounded-lg border text-xs font-semibold transition-all cursor-pointer ${
              isVoiceAnnouncing
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 animate-pulse'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Voice AI Announce Status"
          >
            <Volume2 className="w-3.5 h-3.5" />
          </button>
          
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 text-xs cursor-pointer"
            title="Minimize to Compact Badge"
          >
            <Minimize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Status & Live Safety Meter Mini Display */}
      <div className="bg-[#0A0C10] border border-slate-800/90 rounded-2xl p-3 mb-3 grid grid-cols-2 gap-2 text-xs">
        <div>
          <span className="text-[10px] text-slate-400 block mb-0.5">Route Safety Rating</span>
          <div className="flex items-center gap-1.5 font-bold text-emerald-400 text-sm">
            <ShieldCheck className="w-4 h-4" />
            <span>{safetyScore}% Safest</span>
          </div>
          <span className="text-[10px] text-slate-500 truncate block mt-0.5">{activeRouteName}</span>
        </div>

        <div className="border-l border-slate-800/80 pl-2.5">
          <span className="text-[10px] text-slate-400 block mb-0.5">Nearest SafeHaven</span>
          <div className="flex items-center gap-1.5 font-bold text-slate-200 text-xs truncate">
            <Building2 className="w-3.5 h-3.5 text-teal-400 shrink-0" />
            <span className="truncate">{nearestHavenName}</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-semibold block mt-0.5">24/7 Verified Safe</span>
        </div>
      </div>

      {/* Check-In Timer Status Banner in Widget */}
      {activeTimerMinutes !== null ? (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-2.5 mb-3 flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
            <div>
              <span className="font-bold text-amber-300 block text-xs">Guardian Timer Active</span>
              <span className="text-[10px] text-amber-200/80">{activeTimerMinutes} min remaining</span>
            </div>
          </div>
          <button
            onClick={onCheckInSafe}
            className="px-2.5 py-1 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-[11px] shadow-sm cursor-pointer shrink-0"
          >
            Check In Safe
          </button>
        </div>
      ) : null}

      {/* Primary 1-Tap Widget Action Buttons */}
      <div className="grid grid-cols-5 gap-1.5">
        
        {/* SOS Button */}
        <button
          onClick={onOpenSOS}
          className="flex flex-col items-center justify-center py-2.5 px-1 rounded-2xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-200 border border-rose-500/40 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-rose-600 group-hover:bg-rose-500 flex items-center justify-center text-white font-black text-xs shadow-md mb-1 transition-transform group-hover:scale-105">
            SOS
          </div>
          <span className="text-[10px] font-bold">1-Tap SOS</span>
        </button>

        {/* Share Live Link */}
        <button
          onClick={onOpenShareProgress}
          className="flex flex-col items-center justify-center py-2.5 px-1 rounded-2xl bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 border border-teal-500/30 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-teal-600/30 group-hover:bg-teal-600/50 flex items-center justify-center text-teal-300 mb-1">
            <Share2 className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-bold truncate max-w-full">Share Link</span>
        </button>

        {/* Fake Call Button */}
        <button
          onClick={onOpenFakeCall}
          className="flex flex-col items-center justify-center py-2.5 px-1 rounded-2xl bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-indigo-600/30 group-hover:bg-indigo-600/50 flex items-center justify-center text-indigo-300 mb-1">
            <PhoneCall className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-bold">Fake Call</span>
        </button>

        {/* Voice AI Assistant */}
        <button
          onClick={onOpenAIChat}
          className="flex flex-col items-center justify-center py-2.5 px-1 rounded-2xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-cyan-600/30 group-hover:bg-cyan-600/50 flex items-center justify-center text-cyan-300 mb-1">
            <Mic className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-bold">Voice AI</span>
        </button>

        {/* Quick 10-Min Timer Start */}
        <button
          onClick={() => onQuickStartTimer(10)}
          className="flex flex-col items-center justify-center py-2.5 px-1 rounded-2xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-600/30 group-hover:bg-emerald-600/50 flex items-center justify-center text-emerald-300 mb-1">
            <Clock className="w-4 h-4" />
          </div>
          <span className="text-[10px] font-bold">Quick 10m</span>
        </button>

      </div>
    </div>
  );
};
