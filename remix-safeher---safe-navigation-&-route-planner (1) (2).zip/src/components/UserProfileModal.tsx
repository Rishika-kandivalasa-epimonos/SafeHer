import React, { useState } from 'react';
import {
  User,
  X,
  MapPin,
  Home,
  Briefcase,
  Phone,
  Mail,
  HeartPulse,
  ShieldCheck,
  CheckCircle2,
  Navigation,
  Crosshair,
  Volume2,
  Save,
  Sliders,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { UserProfile, LocationCoordinates, TravelMode } from '../types';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onSaveProfile: (updated: UserProfile) => void;
  onSetLocationAsOrigin: (address: string, coords?: LocationCoordinates) => void;
  onSetLocationAsDestination: (address: string, coords?: LocationCoordinates) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onSaveProfile,
  onSetLocationAsOrigin,
  onSetLocationAsDestination,
}) => {
  const [profile, setProfile] = useState<UserProfile>(userProfile);
  const [isLocating, setIsLocating] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isOpen) return null;

  const handleGetCurrentGPS = async () => {
    setIsLocating(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          let addressName = `Location near (${lat.toFixed(4)}°, ${lng.toFixed(4)}°)`;
          
          try {
            // Reverse geocode using OpenStreetMap / Google Maps reverse geocode format
            const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
            if (res.ok) {
              const data = await res.json();
              if (data && data.display_name) {
                const parts = data.display_name.split(', ');
                addressName = parts.slice(0, 3).join(', ');
              }
            }
          } catch (e) {
            console.warn('Reverse geocode failed:', e);
          }

          setProfile((prev) => ({
            ...prev,
            currentAddress: addressName,
            currentCoordinates: { lat, lng },
          }));
          setIsLocating(false);
        },
        (error) => {
          console.warn('Geolocation error:', error);
          // Auto fallback location for India (Bengaluru)
          const fallbackLat = 12.9756;
          const fallbackLng = 77.6068;
          setProfile((prev) => ({
            ...prev,
            currentAddress: 'MG Road Metro Station, Bengaluru, Karnataka, India',
            currentCoordinates: { lat: fallbackLat, lng: fallbackLng },
          }));
          setIsLocating(false);
        },
        { enableHighAccuracy: true, timeout: 5000 }
      );
    } else {
      setIsLocating(false);
    }
  };

  const handleSave = () => {
    onSaveProfile(profile);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-[#161B22] border border-slate-800 rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl text-slate-100 relative my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-blue-600/30">
              {profile.name.charAt(0) || 'U'}
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                User Safety Profile
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Verified ID
                </span>
              </h2>
              <p className="text-xs text-slate-400">Manage personal info, custom GPS locations & safety preferences</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Save Success Toast */}
        {saveSuccess && (
          <div className="mb-4 bg-emerald-500 text-slate-950 px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-2 animate-bounce">
            <CheckCircle2 className="w-4 h-4" />
            <span>Profile & Custom Location saved successfully!</span>
          </div>
        )}

        {/* Profile Content Body */}
        <div className="space-y-5 text-xs">
          
          {/* Section 1: Custom Location & Saved Places */}
          <div className="bg-[#0A0C10] border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-emerald-400" />
                Custom Location & Saved Places
              </span>

              <button
                onClick={handleGetCurrentGPS}
                disabled={isLocating}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30 hover:bg-emerald-500/30 transition-all cursor-pointer"
              >
                <Crosshair className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
                <span>{isLocating ? 'Detecting GPS...' : 'Use Current GPS'}</span>
              </button>
            </div>

            {/* Current Address Input */}
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Current Address / Landmark</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={profile.currentAddress}
                  onChange={(e) => setProfile({ ...profile, currentAddress: e.target.value })}
                  placeholder="Enter custom location or street address"
                  className="flex-1 bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
                <button
                  onClick={() => onSetLocationAsOrigin(profile.currentAddress, profile.currentCoordinates)}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl border border-slate-700 transition-colors cursor-pointer"
                >
                  Set Origin
                </button>
              </div>
            </div>

            {/* Auto Google Maps Location Badge & Direct Link */}
            <div className="flex items-center justify-between px-3 py-2 bg-[#161B22] rounded-xl border border-slate-800/80 text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>Google Maps Location Sync: <strong className="text-emerald-300 font-semibold">Active</strong></span>
              </span>
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${profile.currentCoordinates.lat},${profile.currentCoordinates.lng}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-[10px] text-blue-400 hover:text-blue-300 font-semibold cursor-pointer underline"
              >
                <span>View in Google Maps</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            {/* Saved Home & Work Addresses */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
              
              {/* Home Address */}
              <div className="bg-[#161B22] p-3 rounded-xl border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200 flex items-center gap-1">
                    <Home className="w-3.5 h-3.5 text-blue-400" /> Home
                  </span>
                  <div className="flex gap-1">
                    <button
                      onClick={() => onSetLocationAsOrigin(profile.homeAddress)}
                      className="text-[9px] font-bold text-blue-400 hover:underline cursor-pointer"
                    >
                      Origin
                    </button>
                    <span className="text-slate-600">•</span>
                    <button
                      onClick={() => onSetLocationAsDestination(profile.homeAddress)}
                      className="text-[9px] font-bold text-emerald-400 hover:underline cursor-pointer"
                    >
                      Dest
                    </button>
                  </div>
                </div>
                <input
                  type="text"
                  value={profile.homeAddress}
                  onChange={(e) => setProfile({ ...profile, homeAddress: e.target.value })}
                  placeholder="e.g. 742 Evergreen Terrace, SF"
                  className="w-full bg-[#0A0C10] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Work Address */}
              <div className="bg-[#161B22] p-3 rounded-xl border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200 flex items-center gap-1">
                    <Briefcase className="w-3.5 h-3.5 text-purple-400" /> Work / School
                  </span>
                  <div className="flex gap-1">
                    <button
                      onClick={() => onSetLocationAsOrigin(profile.workAddress)}
                      className="text-[9px] font-bold text-blue-400 hover:underline cursor-pointer"
                    >
                      Origin
                    </button>
                    <span className="text-slate-600">•</span>
                    <button
                      onClick={() => onSetLocationAsDestination(profile.workAddress)}
                      className="text-[9px] font-bold text-emerald-400 hover:underline cursor-pointer"
                    >
                      Dest
                    </button>
                  </div>
                </div>
                <input
                  type="text"
                  value={profile.workAddress}
                  onChange={(e) => setProfile({ ...profile, workAddress: e.target.value })}
                  placeholder="e.g. 100 Howard St, SF"
                  className="w-full bg-[#0A0C10] border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-purple-500"
                />
              </div>

            </div>
          </div>

          {/* Section 2: Personal & Contact Info */}
          <div className="bg-[#0A0C10] border border-slate-800 rounded-2xl p-4 space-y-3">
            <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <User className="w-4 h-4 text-blue-400" />
              Personal Contact Details
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Full Name</label>
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Phone Number</label>
                <input
                  type="text"
                  value={profile.phone}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-400 font-semibold mb-1">Email Address</label>
                <input
                  type="email"
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Emergency Medical & First Responder Notes */}
          <div className="bg-[#0A0C10] border border-slate-800 rounded-2xl p-4 space-y-3">
            <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <HeartPulse className="w-4 h-4 text-rose-400" />
              Emergency Medical Info (Included with SOS Signals)
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Blood Type</label>
                <input
                  type="text"
                  value={profile.bloodType}
                  onChange={(e) => setProfile({ ...profile, bloodType: e.target.value })}
                  placeholder="e.g. O Positive (O+)"
                  className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-400 font-semibold mb-1">Medical Conditions & Allergies</label>
                <input
                  type="text"
                  value={profile.medicalNotes}
                  onChange={(e) => setProfile({ ...profile, medicalNotes: e.target.value })}
                  placeholder="e.g. Asthma (Inhaler), Penicillin Allergy"
                  className="w-full bg-[#161B22] border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Safety & Navigation Preferences */}
          <div className="bg-[#0A0C10] border border-slate-800 rounded-2xl p-4 space-y-3">
            <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-indigo-400" />
              Safety & Navigation Toggles
            </span>

            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-200 block">Auto-Voice Navigation Assistant</span>
                  <span className="text-[10px] text-slate-400">Read AI safety updates aloud hands-free</span>
                </div>
                <button
                  onClick={() => setProfile({ ...profile, autoVoiceNav: !profile.autoVoiceNav })}
                  className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                    profile.autoVoiceNav ? 'bg-indigo-600 justify-end' : 'bg-slate-800 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-md" />
                </button>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                <div>
                  <span className="font-semibold text-slate-200 block">Broadcast Live GPS to Guardians</span>
                  <span className="text-[10px] text-slate-400">Share continuous location telemetry during active walks</span>
                </div>
                <button
                  onClick={() =>
                    setProfile({
                      ...profile,
                      shareLiveLocationWithGuardians: !profile.shareLiveLocationWithGuardians,
                    })
                  }
                  className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                    profile.shareLiveLocationWithGuardians ? 'bg-emerald-500 justify-end' : 'bg-slate-800 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-md" />
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-5 mt-5 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>

          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Profile & Location</span>
          </button>
        </div>

      </div>
    </div>
  );
};
