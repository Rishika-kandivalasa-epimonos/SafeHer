import React, { useState, useEffect } from 'react';
import { EmergencyContact, LocationCoordinates } from '../types';
import { startEmergencySiren, stopEmergencySiren } from '../utils/audio';
import {
  Radio,
  Volume2,
  VolumeX,
  PhoneCall,
  MessageSquare,
  Send,
  MapPin,
  X,
  ShieldAlert,
  CheckCircle2,
  AlertOctagon
} from 'lucide-react';

interface EmergencySOSModalProps {
  isOpen: boolean;
  onClose: () => void;
  userLocation: LocationCoordinates;
  contacts: EmergencyContact[];
  onLogSOSHistory: (recipientNames: string[]) => void;
}

export const EmergencySOSModal: React.FC<EmergencySOSModalProps> = ({
  isOpen,
  onClose,
  userLocation,
  contacts,
  onLogSOSHistory,
}) => {
  const [isSirenActive, setIsSirenActive] = useState(false);
  const [alertSent, setAlertSent] = useState(false);

  useEffect(() => {
    if (isOpen && !alertSent) {
      // Auto-trigger distress alert broadcast log
      const names = contacts.map(c => c.name);
      onLogSOSHistory(names.length > 0 ? names : ['Default Emergency Circle']);
      setAlertSent(true);
    }
  }, [isOpen, alertSent, contacts, onLogSOSHistory]);

  const toggleSiren = () => {
    if (isSirenActive) {
      stopEmergencySiren();
      setIsSirenActive(false);
    } else {
      startEmergencySiren();
      setIsSirenActive(true);
    }
  };

  const handleClose = () => {
    stopEmergencySiren();
    setIsSirenActive(false);
    setAlertSent(false);
    onClose();
  };

  if (!isOpen) return null;

  const mapsUrl = `https://maps.google.com/?q=${userLocation.lat},${userLocation.lng}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-rose-950/90 backdrop-blur-xl animate-sos-strobe">
      <div className="bg-[#161B22] border-2 border-rose-500 w-full max-w-lg rounded-3xl shadow-2xl p-6 space-y-5 text-slate-100 relative overflow-hidden">
        
        {/* Top Emergency Strobe Badge */}
        <div className="flex items-center justify-between border-b border-rose-500/30 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-600 flex items-center justify-center text-white shadow-lg shadow-rose-600/50 animate-bounce">
              <Radio className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-heading font-black text-xl text-rose-400">EMERGENCY SOS ACTIVE</h2>
              <p className="text-xs text-rose-200">Distress signal transmitting via SafeHer Guard Mesh</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live GPS Broadcast Box */}
        <div className="bg-[#0A0C10] border border-rose-500/40 p-4 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-rose-300">
            <span className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-rose-400 animate-ping" /> Live Location Beacon
            </span>
            <span className="bg-rose-500/20 text-rose-300 px-2.5 py-0.5 rounded-full border border-rose-500/30 text-[10px]">
              GPS Accuracy: High
            </span>
          </div>

          <p className="text-xs text-slate-300 font-mono bg-slate-900 p-2.5 rounded-xl border border-slate-800 break-all">
            EMERGENCY DISTRESS: I need help at lat: {userLocation.lat.toFixed(4)}, lng: {userLocation.lng.toFixed(4)}! Track me live: {mapsUrl}
          </p>

          <div className="flex items-center gap-2 text-[11px] text-emerald-400 font-semibold pt-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Alert dispatched to {contacts.length || 3} Emergency Contacts</span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="space-y-3">
          
          {/* Siren Button */}
          <button
            onClick={toggleSiren}
            className={`w-full py-4 px-4 rounded-2xl font-bold text-sm shadow-xl flex items-center justify-center gap-3 transition-all cursor-pointer ${
              isSirenActive
                ? 'bg-amber-400 text-slate-950 shadow-amber-500/30 animate-pulse'
                : 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/40'
            }`}
          >
            {isSirenActive ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            <span>{isSirenActive ? 'STOP EMERGENCY SIREN' : 'SOUND LOUD ALARM SIREN'}</span>
          </button>

          {/* Direct Emergency Call Options */}
          <div className="grid grid-cols-2 gap-2">
            <a
              href="tel:112"
              className="py-3 px-3 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              title="Call 112 National Emergency Response System India"
            >
              <PhoneCall className="w-4 h-4" />
              <span>DIAL 112 (INDIA)</span>
            </a>

            <a
              href="tel:1091"
              className="py-3 px-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              title="Call 1091 Women Safety Helpline India"
            >
              <PhoneCall className="w-4 h-4 text-pink-300" />
              <span>1091 (WOMEN HELPLINE)</span>
            </a>
          </div>

          <a
            href="tel:911"
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-[11px] flex items-center justify-center gap-2 transition-all cursor-pointer border border-slate-700"
          >
            <PhoneCall className="w-3.5 h-3.5 text-blue-400" />
            <span>DIAL 911 (US / International Dispatch)</span>
          </a>

        </div>

        {/* Contact List Status & Direct Call/WhatsApp Dispatch */}
        <div className="bg-[#0A0C10] p-3.5 rounded-2xl border border-slate-800 text-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">
              Direct Emergency Dispatch to Trusted Circle
            </span>
            <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Auto-Dispatched
            </span>
          </div>
          
          <div className="space-y-2 max-h-36 overflow-y-auto">
            {contacts.map((c) => {
              const clean = c.phone.replace(/[^0-9]/g, '');
              const waPhone = clean.length === 10 ? '91' + clean : clean;
              const waMsg = encodeURIComponent(
                `🚨 EMERGENCY DISTRESS ALERT: I need urgent help! Track my live location here: ${mapsUrl}`
              );
              return (
                <div key={c.id} className="flex items-center justify-between bg-slate-900 p-2 rounded-xl border border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{c.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{c.phone}</span>
                  </div>
                  
                  <div className="flex items-center gap-1.5">
                    <a
                      href={`tel:${c.phone.replace(/[^0-9+]/g, '')}`}
                      className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer border border-emerald-500/30"
                      title={`Call ${c.name} directly`}
                    >
                      <PhoneCall className="w-3 h-3 text-emerald-400" />
                      <span>Call Phone</span>
                    </a>

                    <a
                      href={`https://wa.me/${waPhone}?text=${waMsg}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1 rounded-lg bg-green-600/20 hover:bg-green-600/30 text-green-300 font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer border border-green-500/40"
                      title={`Send WhatsApp distress message to ${c.name}`}
                    >
                      <MessageSquare className="w-3 h-3 text-green-400" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Cancel Safety Button */}
        <button
          onClick={handleClose}
          className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors cursor-pointer border border-slate-700"
        >
          I am Safe Now (Dismiss Emergency Alert)
        </button>

      </div>
    </div>
  );
};
