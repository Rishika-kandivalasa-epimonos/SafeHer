import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import {
  SafeHaven,
  CommunityIncident,
  SafeRouteOption,
  LocationCoordinates,
  HavenType
} from '../types';
import { Layers, Shield, Eye, Flame, MapPin, Compass, ExternalLink } from 'lucide-react';

interface MapContainerProps {
  center: LocationCoordinates;
  zoom: number;
  selectedRoute: SafeRouteOption | null;
  allRoutes: SafeRouteOption[];
  havens: SafeHaven[];
  incidents: CommunityIncident[];
  userLocation: LocationCoordinates;
  onSelectHaven: (haven: SafeHaven) => void;
  onSelectIncident: (incident: CommunityIncident) => void;
  showLightingHeatmap: boolean;
  onToggleLightingHeatmap: () => void;
}

export const MapContainer: React.FC<MapContainerProps> = ({
  center,
  zoom,
  selectedRoute,
  allRoutes,
  havens,
  incidents,
  userLocation,
  onSelectHaven,
  onSelectIncident,
  showLightingHeatmap,
  onToggleLightingHeatmap,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);
  const [mapTileStyle, setMapTileStyle] = useState<'dark' | 'voyager' | 'street'>('dark');

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [center.lat, center.lng],
        zoom: zoom,
        zoomControl: false,
      });

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      mapInstanceRef.current = map;
      layerGroupRef.current = L.layerGroup().addTo(map);
    } else {
      mapInstanceRef.current.setView([center.lat, center.lng], zoom);
    }

    return () => {
      // Keep map mounted across simple state changes
    };
  }, [center.lat, center.lng, zoom]);

  // Update Tiles & Overlays whenever routes, havens, incidents or mapTileStyle change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Remove existing tile layers
    map.eachLayer((layer) => {
      if (layer instanceof L.TileLayer) {
        map.removeLayer(layer);
      }
    });

    let tileUrl = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
    let attribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/">CARTO</a>';

    if (mapTileStyle === 'voyager') {
      tileUrl = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
    } else if (mapTileStyle === 'street') {
      tileUrl = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    }

    L.tileLayer(tileUrl, { attribution, maxZoom: 19 }).addTo(map);

    // Clear previous markers & polylines
    if (layerGroupRef.current) {
      layerGroupRef.current.clearLayers();
    }

    const group = layerGroupRef.current || L.layerGroup().addTo(map);

    // 1. Draw User Location Marker
    const userHtml = `
      <div class="relative flex items-center justify-center w-8 h-8">
        <div class="absolute w-8 h-8 bg-emerald-500/30 rounded-full pulse-location"></div>
        <div class="w-4 h-4 bg-emerald-500 border-2 border-white rounded-full shadow-lg"></div>
      </div>
    `;
    const userIcon = L.divIcon({
      html: userHtml,
      className: '',
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });
    L.marker([userLocation.lat, userLocation.lng], { icon: userIcon })
      .bindPopup('<b>Your Current Location</b><br/>SafeHer Guard Mesh Active')
      .addTo(group);

    // 2. Draw Routes Polylines
    const routesToDraw = allRoutes.length > 0 ? allRoutes : (selectedRoute ? [selectedRoute] : []);

    routesToDraw.forEach((route) => {
      const isSelected = selectedRoute ? route.id === selectedRoute.id : true;
      let strokeColor = '#10b981'; // Safest (Emerald)
      if (route.type === 'fastest') strokeColor = '#f59e0b'; // Amber
      if (route.type === 'well_lit') strokeColor = '#06b6d4'; // Cyan

      const latLngs = route.pathCoordinates.map((c) => [c.lat, c.lng] as [number, number]);

      if (latLngs.length > 1) {
        // Outer glow
        L.polyline(latLngs, {
          color: strokeColor,
          weight: isSelected ? 8 : 3,
          opacity: isSelected ? 0.35 : 0.1,
        }).addTo(group);

        // Core line
        L.polyline(latLngs, {
          color: strokeColor,
          weight: isSelected ? 5 : 2,
          opacity: isSelected ? 0.95 : 0.4,
          dashArray: route.type === 'fastest' ? '6, 6' : undefined,
        }).addTo(group);

        // Start & End Pins for Selected Route
        if (isSelected) {
          const startPoint = latLngs[0];
          const endPoint = latLngs[latLngs.length - 1];

          const startHtml = `<div class="w-7 h-7 rounded-full bg-emerald-500 text-slate-950 font-black flex items-center justify-center text-[11px] shadow-lg border-2 border-white">A</div>`;
          const endHtml = `<div class="w-7 h-7 rounded-full bg-indigo-600 text-white font-black flex items-center justify-center text-[11px] shadow-lg border-2 border-white">B</div>`;

          L.marker(startPoint, {
            icon: L.divIcon({ html: startHtml, className: '', iconSize: [28, 28], iconAnchor: [14, 14] }),
          }).bindPopup(`<b>Origin Point (A)</b><br/>${selectedRoute.name}`).addTo(group);

          L.marker(endPoint, {
            icon: L.divIcon({ html: endHtml, className: '', iconSize: [28, 28], iconAnchor: [14, 14] }),
          }).bindPopup(`<b>Destination Point (B)</b><br/>${selectedRoute.name}`).addTo(group);
        }
      }
    });

    // Auto fit map view to selected route path
    if (selectedRoute && selectedRoute.pathCoordinates && selectedRoute.pathCoordinates.length > 0) {
      const bounds = L.latLngBounds(
        selectedRoute.pathCoordinates.map((c) => [c.lat, c.lng] as [number, number])
      );
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50], maxZoom: 16 });
      }
    }

    // 3. Draw Safe Havens Markers
    havens.forEach((haven) => {
      const havenBg = getHavenColor(haven.type);
      const havenIconChar = getHavenSymbol(haven.type);

      const html = `
        <div class="group relative flex items-center justify-center w-7 h-7 rounded-lg ${havenBg} text-white shadow-md border border-white/20 hover:scale-110 transition-transform cursor-pointer">
          <span class="text-xs font-bold">${havenIconChar}</span>
        </div>
      `;

      const icon = L.divIcon({
        html,
        className: '',
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      const havenMarker = L.marker([haven.coordinates.lat, haven.coordinates.lng], { icon }).addTo(group);

      havenMarker.bindPopup(`
        <div class="p-1 text-slate-100">
          <div class="flex items-center gap-1.5 font-bold text-xs text-emerald-400">
            <span>${havenIconChar}</span>
            <span>${haven.name}</span>
          </div>
          <p class="text-[11px] text-slate-300 mt-1">${haven.address}</p>
          <div class="flex items-center justify-between mt-2 pt-2 border-t border-slate-800 text-[10px] text-slate-400">
            <span>${haven.isOpen24Hours ? '🟢 Open 24/7' : '🟡 Limited Hours'}</span>
            <span class="text-emerald-400 font-medium">Verified Haven</span>
          </div>
        </div>
      `);

      havenMarker.on('click', () => onSelectHaven(haven));
    });

    // 4. Draw Community Incident Markers
    incidents.forEach((incident) => {
      let badgeBg = 'bg-amber-500';
      if (incident.severity === 'high' || incident.severity === 'critical') badgeBg = 'bg-rose-600 animate-bounce';

      const html = `
        <div class="flex items-center justify-center w-7 h-7 rounded-full ${badgeBg} text-white shadow-lg border-2 border-slate-900 cursor-pointer">
          <span class="text-[11px] font-bold">⚠️</span>
        </div>
      `;

      const icon = L.divIcon({
        html,
        className: '',
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      const incMarker = L.marker([incident.coordinates.lat, incident.coordinates.lng], { icon }).addTo(group);

      incMarker.bindPopup(`
        <div class="p-1 text-slate-100">
          <div class="flex items-center gap-1 text-xs font-bold text-amber-400">
            <span>⚠️</span>
            <span>${incident.title}</span>
          </div>
          <p class="text-[11px] text-slate-300 mt-1">${incident.description}</p>
          <div class="mt-2 pt-1 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
            <span>Severity: <strong class="uppercase text-amber-300">${incident.severity}</strong></span>
            <span>👍 ${incident.upvotes} Verifications</span>
          </div>
        </div>
      `);

      incMarker.on('click', () => onSelectIncident(incident));
    });

    // 5. Optional Lighting Heatmap Overlay Circles
    if (showLightingHeatmap) {
      // Add lighting glow circles around main commercial corridors
      const lightingPoints = [
        { lat: 37.7892, lng: -122.3995, radius: 250, opacity: 0.2 },
        { lat: 37.7865, lng: -122.4048, radius: 300, opacity: 0.25 },
        { lat: 37.7844, lng: -122.4080, radius: 320, opacity: 0.22 },
      ];

      lightingPoints.forEach((pt) => {
        L.circle([pt.lat, pt.lng], {
          color: '#38bdf8',
          fillColor: '#38bdf8',
          fillOpacity: pt.opacity,
          radius: pt.radius,
          stroke: false,
        }).addTo(group);
      });
    }

  }, [mapTileStyle, selectedRoute, allRoutes, havens, incidents, userLocation, showLightingHeatmap, onSelectHaven, onSelectIncident]);

  return (
    <div className="relative w-full h-full rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
      {/* Map Container Element */}
      <div ref={mapContainerRef} className="w-full h-full min-h-[450px]" />

      {/* Floating Top-Left Google Maps Badge */}
      <div className="absolute top-4 left-4 z-20">
        <a
          href={`https://www.google.com/maps/search/?api=1&query=${userLocation.lat},${userLocation.lng}`}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-xl border border-blue-500/40 text-blue-300 shadow-xl flex items-center gap-2 text-xs font-bold hover:bg-blue-600/20 transition-all cursor-pointer"
          title="Open exact current GPS location in Google Maps app"
        >
          <div className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-ping" />
          <MapPin className="w-3.5 h-3.5 text-blue-400" />
          <span>Google Maps Pin: ({userLocation.lat.toFixed(4)}°, {userLocation.lng.toFixed(4)}°)</span>
          <ExternalLink className="w-3 h-3 text-blue-400 ml-0.5" />
        </a>
      </div>

      {/* Floating Map Controls overlay */}
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
        {/* Tile Style Switcher */}
        <div className="bg-slate-900/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-800 shadow-xl flex items-center gap-1">
          <button
            onClick={() => setMapTileStyle('dark')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              mapTileStyle === 'dark' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Dark Mode
          </button>
          <button
            onClick={() => setMapTileStyle('voyager')}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              mapTileStyle === 'voyager' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Light Mode
          </button>
        </div>

        {/* Lighting Heatmap Toggle */}
        <button
          onClick={onToggleLightingHeatmap}
          className={`px-3 py-2 rounded-xl backdrop-blur-md border shadow-xl flex items-center gap-2 text-xs font-semibold transition-all cursor-pointer ${
            showLightingHeatmap
              ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
              : 'bg-slate-900/90 border-slate-800 text-slate-300 hover:bg-slate-800'
          }`}
        >
          <Eye className="w-3.5 h-3.5 text-amber-400" />
          <span>Street Lighting Overlay</span>
        </button>
      </div>

      {/* Map Legend Bar */}
      <div className="absolute bottom-4 left-4 z-20 bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-800 shadow-xl hidden sm:flex items-center gap-4 text-[11px] text-slate-300">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-1 rounded bg-emerald-500"></div>
          <span>Safest (100% Lit)</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-1 rounded bg-amber-500"></div>
          <span>Direct / Caution</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2.5 h-2.5 rounded bg-blue-600 flex items-center justify-center text-[8px] font-bold text-white">🚓</div>
          <span>Safe Haven</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-rose-500"></div>
          <span>Incident Alert</span>
        </div>
      </div>
    </div>
  );
};

function getHavenColor(type: HavenType): string {
  switch (type) {
    case 'police': return 'bg-blue-600';
    case 'hospital': return 'bg-emerald-600';
    case 'store_247': return 'bg-teal-600';
    case 'open_cafe': return 'bg-amber-600';
    case 'transit_hub': return 'bg-purple-600';
    case 'emergency_call_box': return 'bg-rose-600';
    default: return 'bg-indigo-600';
  }
}

function getHavenSymbol(type: HavenType): string {
  switch (type) {
    case 'police': return '👮';
    case 'hospital': return '🏥';
    case 'store_247': return '🏪';
    case 'open_cafe': return '☕';
    case 'transit_hub': return '🚇';
    case 'emergency_call_box': return '🆘';
    default: return '🛡️';
  }
}
