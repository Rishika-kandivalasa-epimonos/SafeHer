import React from 'react';
import {
  ShieldAlert,
  Navigation,
  Sparkles,
  PhoneCall,
  MapPin,
  Clock,
  Radio,
  PlusCircle,
  BarChart3,
  Users,
  History,
  User,
  Share2
} from 'lucide-react';

interface HeaderNavbarProps {
  currentCityName: string;
  cityKey?: string;
  userCurrentLocation?: string;
  onCityChange: (cityKey: string) => void;
  onOpenSOS: () => void;
  onOpenFakeCall: () => void;
  onOpenAIChat: () => void;
  onOpenReportModal: () => void;
  onOpenInsightsModal: () => void;
  onOpenContactsModal: () => void;
  onOpenHistoryModal: () => void;
  onOpenProfileModal: () => void;
  onOpenShareProgressModal: () => void;
  activeGuardianMinutes: number | null;
  historyCount: number;
  userName?: string;
}

export const HeaderNavbar: React.FC<HeaderNavbarProps> = ({
  currentCityName,
  cityKey = 'current_location',
  userCurrentLocation,
  onCityChange,
  onOpenSOS,
  onOpenFakeCall,
  onOpenAIChat,
  onOpenReportModal,
  onOpenInsightsModal,
  onOpenContactsModal,
  onOpenHistoryModal,
  onOpenProfileModal,
  onOpenShareProgressModal,
  activeGuardianMinutes,
  historyCount,
  userName = 'Rishika K',
}) => {
  return (
    <header className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 sticky top-0 z-30 px-3 lg:px-6 py-2.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        
        {/* Brand & City Selector */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-emerald-500/20">
              <ShieldAlert className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-heading font-bold text-lg text-white tracking-tight">SafeHer</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase tracking-wider">
                  Guard
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">Smart Safe Walking Navigation</p>
            </div>
          </div>

          <div className="h-5 w-px bg-slate-800 mx-1 hidden md:block" />

          {/* User's Current Location Badge beside SafeHer Guard */}
          <button
            onClick={() => {
              onCityChange('current_location');
              onOpenProfileModal();
            }}
            className="flex items-center gap-2 bg-slate-800/90 hover:bg-slate-800 px-3 py-1.5 rounded-xl border border-emerald-500/30 hover:border-emerald-400 transition-all cursor-pointer group shadow-sm"
            title="Switch to your live Current Location in India"
          >
            <div className="relative flex items-center justify-center">
              <span className="animate-ping absolute inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400 opacity-75"></span>
              <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0 relative" />
            </div>
            <div className="flex flex-col text-left max-w-[120px] sm:max-w-[180px] leading-tight">
              <span className="text-[9px] uppercase tracking-wider text-emerald-400 font-bold flex items-center gap-1">
                Current Location
              </span>
              <span className="text-xs font-semibold text-slate-100 truncate group-hover:text-emerald-300">
                {userCurrentLocation || currentCityName}
              </span>
            </div>
          </button>

          {/* SafeHer Guard City Hub Selector */}
          <div className="relative hidden sm:flex items-center">
            <select
              value={cityKey}
              onChange={(e) => onCityChange(e.target.value)}
              className="bg-slate-800 text-xs font-semibold text-emerald-300 border border-slate-700 hover:border-emerald-500/50 rounded-xl px-2.5 py-1.5 focus:outline-none cursor-pointer pr-7 appearance-none"
              title="Select SafeHer Guard City Region"
            >
              <optgroup label="📍 Live India Location Hub">
                <option value="current_location">📍 My Current Location (India)</option>
              </optgroup>
              <optgroup label="🇮🇳 India SafeHer Hubs">
                <option value="bengaluru">🇮🇳 Bengaluru (Bangalore)</option>
                <option value="mumbai">🇮🇳 Mumbai, Maharashtra</option>
                <option value="delhi">🇮🇳 New Delhi / NCR</option>
                <option value="hyderabad">🇮🇳 Hyderabad, Telangana</option>
              </optgroup>
              <optgroup label="🇺🇸 Global SafeHer Hubs">
                <option value="san_francisco">🇺🇸 San Francisco, CA</option>
                <option value="new_york">🇺🇸 New York, NY</option>
              </optgroup>
            </select>
            <div className="pointer-events-none absolute right-2 text-slate-400 text-[10px]">▼</div>
          </div>
        </div>

        {/* Center Live Tracker Badge */}
        <div className="hidden xl:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/50 border border-slate-700/60 text-xs text-slate-300">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span>Live Safety Mesh Active</span>
          {activeGuardianMinutes !== null && (
            <span className="flex items-center gap-1 bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded-full border border-amber-500/20 font-medium text-[11px]">
              <Clock className="w-3 h-3" /> Guardian Timer ({activeGuardianMinutes}m)
            </span>
          )}
        </div>

        {/* Actions Toolbar */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          
          {/* Activity History Modal Toggle */}
          <button
            onClick={onOpenHistoryModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-all cursor-pointer relative"
            title="Safety Log & Check-in History"
          >
            <History className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">Logs</span>
            {historyCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-blue-600 text-white text-[10px] font-bold">
                {historyCount}
              </span>
            )}
          </button>

          {/* Report Incident */}
          <button
            onClick={onOpenReportModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-all cursor-pointer"
            title="Report Hazard or Safe Haven"
          >
            <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Report Hazard</span>
          </button>

          {/* City Safety Analytics */}
          <button
            onClick={onOpenInsightsModal}
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-all cursor-pointer"
            title="Neighborhood Safety Scores"
          >
            <BarChart3 className="w-3.5 h-3.5 text-teal-400" />
            <span>Safety Stats</span>
          </button>

          {/* Emergency Contacts */}
          <button
            onClick={onOpenContactsModal}
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-all cursor-pointer"
            title="Emergency Contacts"
          >
            <Users className="w-3.5 h-3.5 text-indigo-400" />
            <span>Guardians</span>
          </button>

          {/* AI Safety Companion Toggle */}
          <button
            onClick={onOpenAIChat}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 text-xs font-medium border border-emerald-500/30 transition-all cursor-pointer shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span className="hidden sm:inline">AI Companion</span>
          </button>

          {/* Fake Call Companion */}
          <button
            onClick={onOpenFakeCall}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 text-xs font-medium border border-indigo-500/30 transition-all cursor-pointer"
            title="Simulate Fake Call"
          >
            <PhoneCall className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden md:inline">Fake Call</span>
          </button>

          {/* Share Live Progress Button */}
          <button
            onClick={onOpenShareProgressModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 text-xs font-semibold border border-teal-500/30 transition-all cursor-pointer shadow-sm"
            title="Share temporary live tracking link with guardians"
          >
            <Share2 className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden lg:inline">Share Live Link</span>
          </button>

          {/* User Profile & Custom Location Settings */}
          <button
            onClick={onOpenProfileModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-200 text-xs font-semibold border border-blue-500/30 transition-all cursor-pointer"
            title="User Profile & Custom Location Settings"
          >
            <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-[10px]">
              {userName.charAt(0) || 'U'}
            </div>
            <span className="hidden xl:inline">{userName}</span>
          </button>

          {/* SOS Primary Red Button */}
          <button
            onClick={onOpenSOS}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 transition-all cursor-pointer active:scale-95 border border-rose-400/40"
          >
            <Radio className="w-4 h-4 animate-ping" />
            <span>SOS</span>
          </button>
        </div>

      </div>
    </header>
  );
};

