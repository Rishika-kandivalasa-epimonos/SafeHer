import React, { useState } from 'react';
import { EmergencyContact, LocationCoordinates } from '../types';
import {
  Radio,
  Volume2,
  VolumeX,
  PhoneCall,
  MessageSquare,
  Send,
  ShieldAlert,
  AlertTriangle,
  X,
  Zap,
  MapPin,
  CheckCircle2
} from 'lucide-react';
import { startEmergencySiren, stopEmergencySiren } from '../utils/audio';

interface SOSModalProps {
  isOpen: boolean;
  onClose: () => void;
  userLocation: LocationCoordinates;
  contacts: EmergencyContact[];
  onBroadcastDistress: (msgText: string) => void;
}

export const SOSModal: React.FC<SOSModalProps> = ({
  isOpen,
  onClose,
  userLocation,
  contacts,
  onBroadcastDistress,
}) => {
  const [sirenPlaying, setSirenPlaying] = useState(false);
  const [strobeActive, setStrobeActive] = useState(false);
  const [broadcastSent, setBroadcastSent] = useState(false);

  if (!isOpen) return null;

  const handleToggleSiren = () => {
    if (sirenPlaying) {
      stopEmergencySiren();
      setSirenPlaying(false);
    } else {
      startEmergencySiren();
      setSirenPlaying(true);
    }
  };

  const handleTriggerBroadcast = () => {
    onBroadcastDistress('EMERGENCY SOS: I need immediate assistance! Please check my live location link.');
    setBroadcastSent(true);
    setTimeout(() => setBroadcastSent(false), 5000);
  };

  const handleCloseModal = () => {
    if (sirenPlaying) {
      stopEmergencySiren();
      setSirenPlaying(false);
    }
    onClose();
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-fade-in ${strobeActive ? 'animate-sos-strobe' : ''}`}>
      <div className="bg-[#161B22] border-2 border-rose-600/60 rounded-3xl max-w-lg w-full p-6 shadow-2xl shadow-rose-900/40 text-slate-100 relative overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-rose-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-lg shadow-rose-600/50">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="font-heading font-black text-xl text-rose-100 tracking-tight">EMERGENCY SOS HUB</h2>
              <p className="text-xs text-rose-300/80">Immediate Panic Alarm & Distress Dispatch</p>
            </div>
          </div>
          <button
            onClick={handleCloseModal}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Dispatch Confirmation Banner */}
        {broadcastSent && (
          <div className="mt-4 p-3 bg-emerald-500/20 border border-emerald-500/50 rounded-2xl flex items-center gap-2 text-xs text-emerald-200 animate-fade-in">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <p className="font-bold">Distress SMS Broadcast Dispatched!</p>
              <p className="text-[11px] text-emerald-300">Sent live GPS coordinates to {contacts.length} emergency contacts.</p>
            </div>
          </div>
        )}

        {/* Big SOS Primary Trigger */}
        <div className="mt-6 flex flex-col items-center justify-center text-center space-y-3">
          <button
            onClick={handleTriggerBroadcast}
            className="w-32 h-32 rounded-full bg-gradient-to-tr from-rose-700 via-rose-600 to-red-500 text-white font-black text-2xl tracking-widest shadow-2xl shadow-rose-600/60 hover:scale-105 active:scale-95 transition-all cursor-pointer border-4 border-white/30 flex flex-col items-center justify-center gap-1"
          >
            <Radio className="w-8 h-8 animate-ping" />
            <span>SOS</span>
          </button>
          <p className="text-xs text-rose-200/80 font-medium">
            Tap to instantly broadcast distress alert & live GPS location to all {contacts.length} guardians
          </p>
        </div>

        {/* Quick Tools Grid */}
        <div className="mt-6 grid grid-cols-2 gap-3">
          
          {/* Audio Siren Synthesizer */}
          <button
            onClick={handleToggleSiren}
            className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
              sirenPlaying
                ? 'bg-rose-600 text-white border-rose-400 shadow-lg shadow-rose-600/40 animate-pulse'
                : 'bg-slate-900 text-slate-200 border-slate-800 hover:border-slate-700'
            }`}
          >
            {sirenPlaying ? <Volume2 className="w-6 h-6 animate-bounce" /> : <VolumeX className="w-6 h-6 text-rose-400" />}
            <span>{sirenPlaying ? 'STOP SIREN ALARM' : 'PLAY LOUD SIREN'}</span>
          </button>

          {/* High-Visibility Strobe */}
          <button
            onClick={() => setStrobeActive(!strobeActive)}
            className={`p-3.5 rounded-2xl border flex flex-col items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
              strobeActive
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg shadow-amber-500/40'
                : 'bg-slate-900 text-slate-200 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Zap className={`w-6 h-6 ${strobeActive ? 'text-slate-950 animate-spin' : 'text-amber-400'}`} />
            <span>{strobeActive ? 'STOP STROBE LIGHT' : 'VISUAL STROBE LIGHT'}</span>
          </button>

        </div>

        {/* Direct Trusted Circle Contact Dispatch */}
        {contacts.length > 0 && (
          <div className="mt-4 p-3.5 bg-slate-900/90 rounded-2xl border border-slate-800 space-y-2">
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">
              Trusted Circle - Call or WhatsApp Direct
            </span>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {contacts.map((c) => {
                const clean = c.phone.replace(/[^0-9]/g, '');
                const waPhone = clean.length === 10 ? '91' + clean : clean;
                const waMsg = encodeURIComponent(
                  `🚨 EMERGENCY DISTRESS ALERT: I need immediate assistance! My current location: https://maps.google.com/?q=${userLocation.lat.toFixed(4)},${userLocation.lng.toFixed(4)}`
                );
                return (
                  <div key={c.id} className="flex items-center justify-between bg-[#0A0C10] p-2 rounded-xl border border-slate-800 text-xs">
                    <div>
                      <span className="font-bold text-slate-100">{c.name}</span>
                      <span className="text-[10px] text-slate-400 ml-1.5 font-mono">{c.phone}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <a
                        href={`tel:${c.phone.replace(/[^0-9+]/g, '')}`}
                        className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer border border-emerald-500/30"
                        title={`Call ${c.name}`}
                      >
                        <PhoneCall className="w-3 h-3 text-emerald-400" />
                        <span>Call</span>
                      </a>
                      <a
                        href={`https://wa.me/${waPhone}?text=${waMsg}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1 rounded-lg bg-green-600/20 hover:bg-green-600/30 text-green-300 font-bold text-[11px] flex items-center gap-1 transition-all cursor-pointer border border-green-500/40"
                        title={`WhatsApp ${c.name}`}
                      >
                        <MessageSquare className="w-3 h-3 text-green-400" />
                        <span>WhatsApp</span>
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Speed Dial Local Police & Emergency 112 / 1091 */}
        <div className="mt-4 p-3.5 bg-slate-900/90 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <PhoneCall className="w-4 h-4 text-rose-400" />
              <div>
                <p className="font-bold text-white">Emergency Helplines</p>
                <p className="text-[10px] text-slate-400">Direct phone call dialers</p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs font-bold">
            <a
              href="tel:112"
              className="py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center gap-1.5 shadow transition-all cursor-pointer"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>DIAL 112 (INDIA)</span>
            </a>
            <a
              href="tel:1091"
              className="py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center gap-1.5 shadow transition-all cursor-pointer"
            >
              <PhoneCall className="w-3.5 h-3.5 text-pink-300" />
              <span>1091 (WOMEN)</span>
            </a>
          </div>
        </div>

        {/* Current GPS Coordinates */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-emerald-400" />
            <span>Coordinates: {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}</span>
          </span>
          <span className="text-emerald-400 font-semibold">GPS Locked</span>
        </div>

      </div>
    </div>
  );
};
