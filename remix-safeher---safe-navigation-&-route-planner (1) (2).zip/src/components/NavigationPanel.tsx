import React, { useState, useMemo, useRef } from 'react';
import {
  SafeRouteOption,
  TravelMode,
  LocationCoordinates,
  UserProfile
} from '../types';
import {
  Navigation,
  Footprints,
  Bike,
  Moon,
  Clock,
  ShieldCheck,
  AlertTriangle,
  Sparkles,
  ChevronRight,
  SunMedium,
  Building2,
  CheckCircle2,
  ArrowRight,
  Shield,
  Filter,
  Eye,
  Zap,
  Volume2,
  Mic,
  MicOff,
  Square,
  Home,
  Briefcase,
  Share2,
  ExternalLink,
  MapPin
} from 'lucide-react';
import { voiceAI, createSpeechRecognizer } from '../utils/speechUtils';

interface NavigationPanelProps {
  routes: SafeRouteOption[];
  selectedRoute: SafeRouteOption | null;
  onSelectRoute: (route: SafeRouteOption) => void;
  travelMode: TravelMode;
  onTravelModeChange: (mode: TravelMode) => void;
  originText: string;
  setOriginText: (val: string) => void;
  destinationText: string;
  setDestinationText: (val: string) => void;
  onRunAIAssessment: () => void;
  isAnalyzingAI: boolean;
  aiAnalysisResult: any;
  userProfile?: UserProfile;
  onOpenShareProgressModal?: () => void;
}

export const NavigationPanel: React.FC<NavigationPanelProps> = ({
  routes,
  selectedRoute,
  onSelectRoute,
  travelMode,
  onTravelModeChange,
  originText,
  setOriginText,
  destinationText,
  setDestinationText,
  onRunAIAssessment,
  isAnalyzingAI,
  aiAnalysisResult,
  userProfile,
  onOpenShareProgressModal,
}) => {
  const [showTurnByTurn, setShowTurnByTurn] = useState(false);
  const [preferSafeHavens, setPreferSafeHavens] = useState(false);
  const [sortBy, setSortBy] = useState<'safest' | 'fastest' | 'lighting'>('safest');
  const [activeListeningField, setActiveListeningField] = useState<'origin' | 'destination' | null>(null);
  const [isSpeakingRoute, setIsSpeakingRoute] = useState(false);

  // AI Safest Path Horizontal Swipe Carousel State & Handlers
  const [activeSlide, setActiveSlide] = useState(0);
  const carouselRef = useRef<HTMLDivElement>(null);

  const handleScrollCarousel = () => {
    if (carouselRef.current) {
      const slideWidth = carouselRef.current.clientWidth;
      if (slideWidth > 0) {
        const index = Math.round(carouselRef.current.scrollLeft / slideWidth);
        if (index >= 0 && index < 4 && index !== activeSlide) {
          setActiveSlide(index);
        }
      }
    }
  };

  const goToSlide = (index: number) => {
    setActiveSlide(index);
    if (carouselRef.current) {
      const slideWidth = carouselRef.current.clientWidth;
      carouselRef.current.scrollTo({
        left: index * slideWidth,
        behavior: 'smooth',
      });
    }
  };

  // Voice Speech-to-text dictation helper
  const handleDictateField = (field: 'origin' | 'destination') => {
    if (activeListeningField === field) {
      setActiveListeningField(null);
      return;
    }

    const recognizer = createSpeechRecognizer(
      (transcript) => {
        if (field === 'origin') setOriginText(transcript);
        else setDestinationText(transcript);
      },
      () => setActiveListeningField(null),
      () => setActiveListeningField(null)
    );

    if (recognizer) {
      try {
        setActiveListeningField(field);
        recognizer.start();
      } catch (e) {
        setActiveListeningField(null);
      }
    } else {
      setActiveListeningField(field);
      setTimeout(() => {
        const simulated = field === 'origin' ? ' SF MOMA 3rd St' : ' Powell St BART Station';
        if (field === 'origin') setOriginText(simulated);
        else setDestinationText(simulated);
        setActiveListeningField(null);
      }, 2000);
    }
  };

  const handleSpeakRouteSummary = (route: SafeRouteOption) => {
    if (isSpeakingRoute) {
      voiceAI.stop();
      setIsSpeakingRoute(false);
      return;
    }

    const speechMessage = `Suggested safest route: ${route.name}. Travel time is approximately ${route.estimatedMinutes} minutes with ${route.lightingScore} percent streetlight coverage, ${route.openHavensCount} verified active SafeHavens, and zero major hazards reported.`;
    setIsSpeakingRoute(true);
    voiceAI.speak(speechMessage).then(() => {
      setIsSpeakingRoute(false);
    });
  };

  // Compute composite safety rank based on real-time lighting, incidents, CCTV, and SafeHavens
  const calculateRouteScore = (route: SafeRouteOption) => {
    const lightingWeight = (route.lightingScore / 100) * 20;
    const cctvWeight = (route.cctvCoverage / 100) * 10;
    const havenWeight = preferSafeHavens ? route.openHavensCount * 18 : route.openHavensCount * 6;
    const incidentPenalty = route.riskPointsCount * 22;

    return route.safetyScore + lightingWeight + cctvWeight + havenWeight - incidentPenalty;
  };

  // Dynamically sorted routes list
  const processedRoutes = useMemo(() => {
    const list = [...routes];
    list.sort((a, b) => {
      if (sortBy === 'fastest') {
        return a.estimatedMinutes - b.estimatedMinutes;
      }
      if (sortBy === 'lighting') {
        return b.lightingScore - a.lightingScore;
      }
      // Default: Safest composite score
      return calculateRouteScore(b) - calculateRouteScore(a);
    });
    return list;
  }, [routes, preferSafeHavens, sortBy]);

  const topSuggestedRoute = processedRoutes[0] || null;

  return (
    <div className="bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-2xl flex flex-col gap-4 text-slate-100 h-full overflow-y-auto">
      
      {/* Search Header & Inputs */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Navigation className="w-4 h-4 text-emerald-400" />
            <h2 className="font-heading font-bold text-base text-white">Route Safety Planner</h2>
          </div>
          <span className="text-[11px] font-medium bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/20 flex items-center gap-1">
            <Shield className="w-3 h-3 text-emerald-400" /> Real-time Mesh
          </span>
        </div>

        {/* Origin & Destination Inputs with Voice Dictation */}
        <div className="space-y-2 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-emerald-400 ring-4 ring-emerald-500/20 shrink-0" title="Origin" />
            <input
              type="text"
              value={originText}
              onChange={(e) => setOriginText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  onRunAIAssessment();
                }
              }}
              placeholder={activeListeningField === 'origin' ? 'Listening...' : 'Origin (e.g. Current Location)'}
              className="bg-transparent text-xs text-slate-200 placeholder-slate-500 focus:outline-none w-full font-medium"
            />
            <button
              onClick={() => handleDictateField('origin')}
              className={`p-1 rounded-lg border text-xs transition-colors cursor-pointer ${
                activeListeningField === 'origin'
                  ? 'bg-rose-600 border-rose-400 text-white animate-pulse'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
              title="Speak origin"
            >
              <Mic className="w-3 h-3" />
            </button>
          </div>

          <div className="ml-1.5 h-3 border-l-2 border-dashed border-slate-700" />

          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-indigo-500 ring-4 ring-indigo-500/20 shrink-0" title="Destination" />
            <input
              type="text"
              value={destinationText}
              onChange={(e) => setDestinationText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  onRunAIAssessment();
                }
              }}
              placeholder={activeListeningField === 'destination' ? 'Listening...' : 'Destination (e.g. Powell St Station)'}
              className="bg-transparent text-xs text-slate-200 placeholder-slate-500 focus:outline-none w-full font-medium"
            />
            <button
              onClick={() => handleDictateField('destination')}
              className={`p-1 rounded-lg border text-xs transition-colors cursor-pointer ${
                activeListeningField === 'destination'
                  ? 'bg-rose-600 border-rose-400 text-white animate-pulse'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
              title="Speak destination"
            >
              <Mic className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Primary Action Button: Calculate & Show Safer Route */}
        <button
          onClick={onRunAIAssessment}
          disabled={isAnalyzingAI || !originText.trim() || !destinationText.trim()}
          className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 active:scale-[0.99] text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isAnalyzingAI ? (
            <>
              <span className="w-3.5 h-3.5 rounded-full border-2 border-slate-950 border-t-transparent animate-spin" />
              <span>Calculating Safest Path with AI...</span>
            </>
          ) : (
            <>
              <Navigation className="w-4 h-4 text-slate-950" />
              <span>Show Safer Route on Map (Press Enter)</span>
              <Zap className="w-3.5 h-3.5 text-slate-950" />
            </>
          )}
        </button>

        {/* Google Maps Actions Row */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <a
            href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(userProfile?.currentAddress || originText || 'Current Location')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-blue-600/15 hover:bg-blue-600/25 border border-blue-500/30 text-blue-300 font-bold transition-all cursor-pointer text-[11px]"
            title="Open user's current location pin directly in Google Maps"
          >
            <MapPin className="w-3.5 h-3.5 text-blue-400" />
            <span>Open Location in Google Maps</span>
            <ExternalLink className="w-3 h-3 text-blue-400" />
          </a>

          <a
            href={`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(originText || 'Current Location')}&destination=${encodeURIComponent(destinationText || 'Destination')}&travelmode=${travelMode === 'walk' ? 'walking' : travelMode === 'bike' ? 'bicycling' : 'driving'}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/30 text-indigo-300 font-bold transition-all cursor-pointer text-[11px]"
            title="Launch turn-by-turn navigation in official Google Maps app"
          >
            <Navigation className="w-3.5 h-3.5 text-indigo-400" />
            <span>Navigate in Google Maps App</span>
            <ExternalLink className="w-3 h-3 text-indigo-400" />
          </a>
        </div>

        {/* Preset quick buttons & Saved Places */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
          <span className="text-slate-500 shrink-0">Saved & Presets:</span>
          {userProfile?.homeAddress && (
            <button
              onClick={() => setDestinationText(userProfile.homeAddress)}
              className="flex items-center gap-1 px-2 py-1 rounded-md bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 shrink-0 transition-colors cursor-pointer border border-blue-500/30 font-semibold"
              title={`Set destination to ${userProfile.homeAddress}`}
            >
              <Home className="w-3 h-3 text-blue-400" />
              <span>Home</span>
            </button>
          )}

          {userProfile?.workAddress && (
            <button
              onClick={() => setDestinationText(userProfile.workAddress)}
              className="flex items-center gap-1 px-2 py-1 rounded-md bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 shrink-0 transition-colors cursor-pointer border border-purple-500/30 font-semibold"
              title={`Set destination to ${userProfile.workAddress}`}
            >
              <Briefcase className="w-3 h-3 text-purple-400" />
              <span>Work</span>
            </button>
          )}

          <button
            onClick={() => {
              setOriginText('MG Road Metro Station');
              setDestinationText('Indiranagar 100ft Road');
            }}
            className="px-2 py-1 rounded-md bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 shrink-0 transition-colors cursor-pointer border border-emerald-500/30 font-semibold"
          >
            🇮🇳 BLR: MG Rd ➔ Indiranagar
          </button>
          <button
            onClick={() => {
              setOriginText('Koramangala 5th Block');
              setDestinationText('HSR Layout Sector 1');
            }}
            className="px-2 py-1 rounded-md bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 shrink-0 transition-colors cursor-pointer border border-emerald-500/30 font-semibold"
          >
            🇮🇳 BLR: Koramangala
          </button>
          <button
            onClick={() => {
              setOriginText('Bandra Railway Station');
              setDestinationText('BKC Tech Promenade');
            }}
            className="px-2 py-1 rounded-md bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 shrink-0 transition-colors cursor-pointer border border-amber-500/30 font-semibold"
          >
            🇮🇳 BOM: Bandra ➔ BKC
          </button>
          <button
            onClick={() => {
              setOriginText('Rajiv Chowk Metro Gate 2');
              setDestinationText('Connaught Place Inner Circle');
            }}
            className="px-2 py-1 rounded-md bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 shrink-0 transition-colors cursor-pointer border border-blue-500/30 font-semibold"
          >
            🇮🇳 DEL: CP Inner Ring
          </button>
          <button
            onClick={() => {
              setOriginText('Raidurg Metro Station');
              setDestinationText('Cyberabad SHE Teams Hub');
            }}
            className="px-2 py-1 rounded-md bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 shrink-0 transition-colors cursor-pointer border border-purple-500/30 font-semibold"
          >
            🇮🇳 HYD: HITEC City
          </button>
          <button
            onClick={() => {
              setOriginText('Mission St & 3rd St');
              setDestinationText('Powell St BART Station');
            }}
            className="px-2 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0 transition-colors cursor-pointer border border-slate-700"
          >
            🇺🇸 SF Downtown
          </button>
        </div>
      </div>

      {/* Travel Modes Selector */}
      <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950/80 rounded-xl border border-slate-800">
        <button
          onClick={() => onTravelModeChange('walking')}
          className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            travelMode === 'walking'
              ? 'bg-emerald-500 text-slate-950 font-bold shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Footprints className="w-3.5 h-3.5" />
          <span>Walk</span>
        </button>

        <button
          onClick={() => onTravelModeChange('night_walk')}
          className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            travelMode === 'night_walk'
              ? 'bg-indigo-600 text-white font-bold shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Moon className="w-3.5 h-3.5 text-indigo-300" />
          <span>Night Guard</span>
        </button>

        <button
          onClick={() => onTravelModeChange('biking')}
          className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            travelMode === 'biking'
              ? 'bg-teal-500 text-slate-950 font-bold shadow-md'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bike className="w-3.5 h-3.5" />
          <span>Bike</span>
        </button>
      </div>

      {/* Safety Preference Controls & SafeHaven Toggle */}
      <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/90 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5 text-emerald-400" />
            Prefer SafeHaven Paths
          </span>
          <button
            onClick={() => setPreferSafeHavens(!preferSafeHavens)}
            className={`w-11 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
              preferSafeHavens ? 'bg-emerald-500 justify-end' : 'bg-slate-800 justify-start'
            }`}
          >
            <div className="w-4 h-4 rounded-full bg-slate-950 shadow-md" />
          </button>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[11px]">
          <span className="text-slate-400 flex items-center gap-1">
            <Filter className="w-3 h-3 text-indigo-400" /> Sort Order:
          </span>
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setSortBy('safest')}
              className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all ${
                sortBy === 'safest' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Safest First
            </button>
            <button
              onClick={() => setSortBy('lighting')}
              className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all ${
                sortBy === 'lighting' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Max Lit
            </button>
            <button
              onClick={() => setSortBy('fastest')}
              className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all ${
                sortBy === 'fastest' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Fastest
            </button>
          </div>
        </div>
      </div>

      {/* ==================== AI SUGGESTED SAFEST PATH HORIZONTAL SWIPE CAROUSEL ==================== */}
      <div className="bg-slate-950/80 border border-emerald-500/30 rounded-2xl p-3.5 space-y-3 shadow-xl relative">
        
        {/* Swipe Header & Controls */}
        <div className="flex flex-col gap-2 border-b border-slate-800 pb-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400 animate-bounce" />
              <h3 className="font-bold text-white text-xs uppercase tracking-wide">AI Suggested Safest Path</h3>
            </div>
            <div className="flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full text-[10px] font-bold text-emerald-300">
              <ArrowRight className="w-3 h-3 text-emerald-400" />
              <span>Swipe Left to Explore</span>
            </div>
          </div>

          {/* Swipeable Slide Tabs / Indicators */}
          <div className="flex items-center justify-between gap-1 pt-1 text-[11px]">
            <div className="flex items-center gap-1 overflow-x-auto pb-0.5 scrollbar-none">
              <button
                onClick={() => goToSlide(0)}
                className={`px-2.5 py-1 rounded-lg font-bold text-[10px] transition-all cursor-pointer shrink-0 border ${
                  activeSlide === 0
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md font-extrabold'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                1. Path Overview
              </button>
              <button
                onClick={() => goToSlide(1)}
                className={`px-2.5 py-1 rounded-lg font-bold text-[10px] transition-all cursor-pointer shrink-0 border ${
                  activeSlide === 1
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md font-extrabold'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                2. Turn Steps ({selectedRoute?.segments?.length || 0})
              </button>
              <button
                onClick={() => goToSlide(2)}
                className={`px-2.5 py-1 rounded-lg font-bold text-[10px] transition-all cursor-pointer shrink-0 border ${
                  activeSlide === 2
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md font-extrabold'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                3. AI Audit
              </button>
              <button
                onClick={() => goToSlide(3)}
                className={`px-2.5 py-1 rounded-lg font-bold text-[10px] transition-all cursor-pointer shrink-0 border ${
                  activeSlide === 3
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md font-extrabold'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                4. All Routes ({processedRoutes.length})
              </button>
            </div>

            {/* Nav Arrows */}
            <div className="flex items-center gap-1 shrink-0">
              <button
                disabled={activeSlide === 0}
                onClick={() => goToSlide(activeSlide - 1)}
                className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 hover:text-white disabled:opacity-30 cursor-pointer text-[10px]"
                title="Previous Slide"
              >
                ◄
              </button>
              <button
                disabled={activeSlide === 3}
                onClick={() => goToSlide(activeSlide + 1)}
                className="px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 hover:text-white disabled:opacity-30 cursor-pointer text-[10px] font-bold"
                title="Next Slide (Swipe Left)"
              >
                ►
              </button>
            </div>
          </div>
        </div>

        {/* Carousel Container (Swipe Left Native Track) */}
        <div
          ref={carouselRef}
          onScroll={handleScrollCarousel}
          className="flex overflow-x-auto snap-x snap-mandatory scroll-smooth gap-4 scrollbar-none py-1"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {/* SLIDE 1: SAFEST PATH OVERVIEW & QUICK ACTIONS */}
          <div className="w-full shrink-0 snap-start space-y-2.5">
            {topSuggestedRoute ? (
              <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-indigo-950/50 border border-emerald-500/40 rounded-xl p-3.5 space-y-2.5 shadow-md">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-extrabold text-white text-sm flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    {topSuggestedRoute.name}
                  </span>
                  <span className="text-[10px] font-extrabold bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full shadow-sm">
                    {topSuggestedRoute.safetyScore}% Safety Score
                  </span>
                </div>

                <p className="text-[11px] text-slate-300 leading-snug">
                  {topSuggestedRoute.summary || 'Selected automatically based on high streetlight coverage, CCTV surveillance, and open SafeHaven proximity.'}
                </p>

                {/* Metrics Pill Grid */}
                <div className="grid grid-cols-3 gap-1.5 bg-slate-950/70 p-2 rounded-lg border border-slate-800/80 text-[10px]">
                  <div className="flex flex-col items-center justify-center p-1 bg-slate-900/80 rounded">
                    <span className="text-slate-400">Light Quality</span>
                    <span className="font-bold text-amber-300">{topSuggestedRoute.lightingScore}% Lit</span>
                  </div>
                  <div className="flex flex-col items-center justify-center p-1 bg-slate-900/80 rounded">
                    <span className="text-slate-400">SafeHavens</span>
                    <span className="font-bold text-emerald-300">{topSuggestedRoute.openHavensCount} Open</span>
                  </div>
                  <div className="flex flex-col items-center justify-center p-1 bg-slate-900/80 rounded">
                    <span className="text-slate-400">Est. Walk</span>
                    <span className="font-bold text-indigo-300">{topSuggestedRoute.estimatedMinutes} mins ({topSuggestedRoute.distanceKm}km)</span>
                  </div>
                </div>

                {/* Quick Action Row */}
                <div className="flex items-center gap-2 pt-1">
                  {onOpenShareProgressModal && (
                    <button
                      onClick={onOpenShareProgressModal}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg bg-teal-500/20 text-teal-300 font-bold text-[11px] border border-teal-500/30 hover:bg-teal-500/30 transition-colors cursor-pointer"
                    >
                      <Share2 className="w-3.5 h-3.5 text-teal-400" />
                      <span>Share Live Link</span>
                    </button>
                  )}
                  <button
                    onClick={() => handleSpeakRouteSummary(topSuggestedRoute)}
                    className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 font-bold text-[11px] border border-emerald-500/30 hover:bg-emerald-500/30 transition-colors cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{isSpeakingRoute ? 'Stop Voice' : 'Voice AI Audio'}</span>
                  </button>
                </div>

                {selectedRoute?.id !== topSuggestedRoute.id ? (
                  <button
                    onClick={() => onSelectRoute(topSuggestedRoute)}
                    className="w-full py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Navigation className="w-3.5 h-3.5 text-slate-950" />
                    <span>Switch to Suggested Safest Route</span>
                  </button>
                ) : (
                  <div className="w-full py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-bold text-[11px] text-center flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Currently Active Safest Route on Map</span>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-xs text-slate-400 text-center py-4">No route selected. Click Calculate Safest Path above.</p>
            )}
          </div>

          {/* SLIDE 2: TURN-BY-TURN SAFE STEPS */}
          <div className="w-full shrink-0 snap-start space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300 bg-slate-900 p-2 rounded-lg border border-slate-800">
              <span className="flex items-center gap-1.5">
                <Footprints className="w-4 h-4 text-emerald-400" />
                <span>Turn-by-Turn Safe Steps</span>
              </span>
              <span className="text-[10px] text-emerald-400 font-mono">
                {selectedRoute?.segments?.length || 0} Segments
              </span>
            </div>

            {selectedRoute && selectedRoute.segments?.length > 0 ? (
              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 text-xs">
                {selectedRoute.segments.map((seg, i) => (
                  <div key={i} className="flex items-start gap-2 bg-slate-950/90 p-2.5 rounded-xl border border-slate-800 text-slate-300">
                    <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold flex items-center justify-center shrink-0 text-[10px] border border-emerald-500/30">
                      {i + 1}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-200">{seg.instruction}</p>
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400">
                        <span className="font-mono text-slate-300">{seg.distanceMeters}m</span>
                        <span className="text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 font-medium">
                          {seg.lightingQuality === 'high' ? '💡 High Lighting' : '🕯️ Moderate Light'}
                        </span>
                        {seg.monitoredByCCTV && (
                          <span className="text-indigo-300 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20 font-medium">
                            📹 CCTV
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 text-center py-6">Select a route to view step-by-step directions.</p>
            )}
          </div>

          {/* SLIDE 3: GEMINI AI SAFETY AUDIT */}
          <div className="w-full shrink-0 snap-start space-y-2">
            <button
              onClick={onRunAIAssessment}
              disabled={isAnalyzingAI}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 hover:opacity-95 text-slate-950 font-bold text-xs shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5 text-slate-950" />
              <span>{isAnalyzingAI ? 'Analyzing Route with Gemini AI...' : 'Run Gemini AI Safety Audit'}</span>
            </button>

            {aiAnalysisResult ? (
              <div className="bg-emerald-950/50 border border-emerald-500/40 rounded-xl p-3 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-300 flex items-center gap-1 text-[11px]">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" /> Gemini AI Audit Summary
                  </span>
                  <span className="font-extrabold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-full text-[10px] border border-emerald-500/30">
                    Safety: {aiAnalysisResult.safetyScore}/100
                  </span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">{aiAnalysisResult.summary}</p>
                {aiAnalysisResult.precautions?.length > 0 && (
                  <div className="space-y-1 pt-1.5 border-t border-emerald-500/20">
                    <span className="font-bold text-emerald-300 text-[10px] uppercase">Recommended Action Items:</span>
                    <ul className="list-disc list-inside text-slate-300 text-[11px] space-y-0.5">
                      {aiAnalysisResult.precautions.map((p: string, idx: number) => (
                        <li key={idx}>{p}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-center space-y-1">
                <ShieldCheck className="w-6 h-6 text-emerald-400 mx-auto" />
                <p className="text-xs font-bold text-slate-200">Gemini AI Audit Ready</p>
                <p className="text-[11px] text-slate-400">Click the button above to run real-time safety evaluation for current lighting, active hazards, and open SafeHavens.</p>
              </div>
            )}
          </div>

          {/* SLIDE 4: COMPARE ALL ROUTE OPTIONS */}
          <div className="w-full shrink-0 snap-start space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-300">
              <span className="uppercase tracking-wider text-[11px] text-slate-400">All Route Choices</span>
              <span className="text-[10px] text-slate-500">{processedRoutes.length} options</span>
            </div>

            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {processedRoutes.map((route) => {
                const isSelected = selectedRoute?.id === route.id;
                const isTopSuggested = topSuggestedRoute?.id === route.id;

                return (
                  <div
                    key={route.id}
                    onClick={() => onSelectRoute(route)}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800/90 border-emerald-500 ring-1 ring-emerald-500/50'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-xs text-white">{route.name}</span>
                        {isTopSuggested && (
                          <span className="bg-emerald-500 text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded uppercase">
                            #1 Safest
                          </span>
                        )}
                      </div>
                      <span className="font-bold text-emerald-400 text-xs">{route.estimatedMinutes} mins</span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                      <span>{route.lightingScore}% Lit</span>
                      <span>{route.openHavensCount} Havens</span>
                      <span>{route.riskPointsCount > 0 ? `⚠️ ${route.riskPointsCount} Hazards` : '✅ Safe'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Bottom Pagination Dots */}
        <div className="flex items-center justify-center gap-1.5 pt-1">
          {[0, 1, 2, 3].map((idx) => (
            <button
              key={idx}
              onClick={() => goToSlide(idx)}
              className={`h-1.5 rounded-full transition-all cursor-pointer ${
                activeSlide === idx ? 'w-6 bg-emerald-400' : 'w-1.5 bg-slate-700 hover:bg-slate-500'
              }`}
            />
          ))}
        </div>

      </div>

    </div>
  );
};

