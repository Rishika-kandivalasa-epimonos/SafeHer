import React from 'react';
import { NeighborhoodSafetyProfile } from '../types';
import { BarChart3, ShieldCheck, SunMedium, AlertCircle, Clock, X, MapPin } from 'lucide-react';

interface SafetyInsightsModalProps {
  isOpen: boolean;
  onClose: () => void;
  neighborhoods: NeighborhoodSafetyProfile[];
  cityName: string;
}

export const SafetyInsightsModal: React.FC<SafetyInsightsModalProps> = ({
  isOpen,
  onClose,
  neighborhoods,
  cityName,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-[#161B22] border border-slate-800 rounded-3xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-6 shadow-2xl text-slate-100 relative">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-heading font-bold text-lg text-white">{cityName} Neighborhood Safety Scores</h2>
              <p className="text-xs text-slate-400">Lighting quality, CCTV density, and safe walking hours</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Neighborhood Cards Grid */}
        <div className="mt-6 space-y-4">
          {neighborhoods.map((n, idx) => (
            <div
              key={idx}
              className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-heading font-bold text-base text-white flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-emerald-400" />
                    <span>{n.name}</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">Crime Category: {n.crimeRateCategory}</p>
                </div>

                <div className="text-right">
                  <span className="text-2xl font-black text-emerald-400 font-heading">{n.overallSafetyIndex}</span>
                  <span className="text-xs text-slate-400 block font-medium">/ 100 Safety Index</span>
                </div>
              </div>

              {/* Index Bars */}
              <div className="grid grid-cols-2 gap-3 text-xs pt-2 border-t border-slate-800/80">
                <div>
                  <div className="flex justify-between mb-1 font-medium text-slate-300">
                    <span className="flex items-center gap-1">
                      <SunMedium className="w-3.5 h-3.5 text-amber-400" /> Street Lighting Index
                    </span>
                    <span className="text-amber-400 font-bold">{n.lightingIndex}%</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="bg-amber-400 h-full rounded-full"
                      style={{ width: `${n.lightingIndex}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1 font-medium text-slate-300">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-indigo-400" /> Optimal Safe Corridor
                    </span>
                    <span className="text-indigo-300 font-semibold">{n.safeHours}</span>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {n.activeHavensCount} Active Verified Havens Nearby
                  </div>
                </div>
              </div>

              {/* Safety Tips */}
              {n.topPrecautions.length > 0 && (
                <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-1">
                  <span className="text-[10px] font-bold text-teal-400 uppercase tracking-wider block">
                    Local Advisory:
                  </span>
                  <ul className="list-disc list-inside space-y-0.5 text-[11px] text-slate-400">
                    {n.topPrecautions.map((p, i) => (
                      <li key={i}>{p}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
