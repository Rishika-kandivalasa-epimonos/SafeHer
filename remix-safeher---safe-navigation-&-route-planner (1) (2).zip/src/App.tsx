import React, { useState, useEffect } from 'react';
import { HeaderNavbar } from './components/HeaderNavbar';
import { MapContainer } from './components/MapContainer';
import { NavigationPanel } from './components/NavigationPanel';
import { ContactsModal } from './components/ContactsModal';
import { CheckInTimerCard } from './components/CheckInTimerCard';
import { EmergencySOSModal } from './components/EmergencySOSModal';
import { FakeCallModal } from './components/FakeCallModal';
import { AIChatDrawer } from './components/AIChatDrawer';
import { InsightsModal } from './components/InsightsModal';
import { ReportIncidentModal } from './components/ReportIncidentModal';
import { HistoryModal } from './components/HistoryModal';
import { VoiceAIWidget } from './components/VoiceAIWidget';
import { MiniHomeScreenWidget } from './components/MiniHomeScreenWidget';
import { UserProfileModal } from './components/UserProfileModal';
import { ShareLiveProgressModal } from './components/ShareLiveProgressModal';
import { voiceAI } from './utils/speechUtils';

import { CITIES_DATA, getCurrentLocationCityPreset } from './data/cityData';
import { INITIAL_HISTORY } from './data/initialHistory';
import {
  SafeHaven,
  CommunityIncident,
  SafeRouteOption,
  EmergencyContact,
  TravelMode,
  LocationCoordinates,
  GuardianTimer,
  HistoryLogEntry,
  UserProfile
} from './types';

import {
  ShieldAlert,
  Radio,
  Clock,
  Users,
  AlertTriangle,
  Sparkles,
  MapPin,
  Send,
  Plus,
  ShieldCheck,
  CheckCircle2,
  Navigation,
  SunMedium,
  PhoneCall,
  UserPlus,
  History,
  Activity,
  BatteryCharging,
  Eye,
  Settings,
  Share2
} from 'lucide-react';

export default function App() {
  const [cityKey, setCityKey] = useState<string>('current_location');
  const activeCity = CITIES_DATA[cityKey] || CITIES_DATA['current_location'] || CITIES_DATA['bengaluru'];

  // Navigation state
  const [originText, setOriginText] = useState('MG Road Metro Station');
  const [destinationText, setDestinationText] = useState('Indiranagar 100ft Road');
  const [travelMode, setTravelMode] = useState<TravelMode>('walking');
  const [routes, setRoutes] = useState<SafeRouteOption[]>(activeCity.sampleRoutes);
  const [selectedRoute, setSelectedRoute] = useState<SafeRouteOption | null>(
    activeCity.sampleRoutes[0] || null
  );

  // Map layer state
  const [havens, setHavens] = useState<SafeHaven[]>(activeCity.havens);
  const [incidents, setIncidents] = useState<CommunityIncident[]>(activeCity.incidents);
  const [showLightingHeatmap, setShowLightingHeatmap] = useState(true);

  // Emergency contacts state with localStorage persistence
  const [contacts, setContacts] = useState<EmergencyContact[]>(() => {
    try {
      const saved = localStorage.getItem('safepath_contacts');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      {
        id: 'c1',
        name: 'Sarah Connor',
        relationship: 'Sister',
        phone: '+1 (555) 234-5678',
        isPrimary: true,
      },
      {
        id: 'c2',
        name: 'Marcus Vance',
        relationship: 'Roommate',
        phone: '+1 (555) 876-5432',
        isPrimary: false,
      },
      {
        id: 'c3',
        name: 'Dad',
        relationship: 'Parent',
        phone: '+1 (555) 901-2345',
        isPrimary: false,
      }
    ];
  });

  useEffect(() => {
    try {
      localStorage.setItem('safepath_contacts', JSON.stringify(contacts));
    } catch (e) {}
  }, [contacts]);

  // Activity & Check-In History state with localStorage persistence
  const [historyLogs, setHistoryLogs] = useState<HistoryLogEntry[]>(() => {
    try {
      const saved = localStorage.getItem('safepath_history');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_HISTORY;
  });

  useEffect(() => {
    try {
      localStorage.setItem('safepath_history', JSON.stringify(historyLogs));
    } catch (e) {}
  }, [historyLogs]);

  // Guardian Check-In Timer state
  const [guardianTimer, setGuardianTimer] = useState<GuardianTimer>({
    active: false,
    targetMinutes: 15,
    remainingSeconds: 0,
    destinationName: 'Home / Apartment',
    contactToNotify: 'Sarah Connor',
  });

  // AI Route Analysis State
  const [isAnalyzingAI, setIsAnalyzingAI] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<any>(null);

  // Modals state
  const [isSOSOpen, setIsSOSOpen] = useState(false);
  const [isContactsOpen, setIsContactsOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isFakeCallOpen, setIsFakeCallOpen] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [isInsightsOpen, setIsInsightsOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isShareProgressOpen, setIsShareProgressOpen] = useState(false);

  // User Profile State with localStorage persistence
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('safepath_user_profile');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      name: 'Rishika K',
      email: 'rishika@example.com',
      phone: '+1 (415) 555-0199',
      bloodType: 'O Positive (O+)',
      medicalNotes: 'Asthma (Inhaler in jacket), No known drug allergies',
      emergencyInfo: 'Notify primary guardian Sarah Connor immediately on SOS',
      homeAddress: 'MG Road, Indiranagar, Bengaluru, Karnataka, India',
      homeCoordinates: { lat: 12.9784, lng: 77.6408 },
      workAddress: 'EPIP Zone, Whitefield, Bengaluru, Karnataka, India',
      workCoordinates: { lat: 12.9716, lng: 77.5946 },
      currentAddress: 'MG Road Metro Station, Bengaluru, Karnataka, India',
      currentCoordinates: { lat: 12.9756, lng: 77.6068 },
      preferredTravelMode: 'walking',
      autoVoiceNav: true,
      shareLiveLocationWithGuardians: true,
    };
  });

  useEffect(() => {
    try {
      localStorage.setItem('safepath_user_profile', JSON.stringify(userProfile));
    } catch (e) {}
  }, [userProfile]);

  // Live Indian Standard Time (IST) Clock & Mesh System Sync
  const getISTFormattedTime = () => {
    try {
      return new Date().toLocaleTimeString('en-US', {
        timeZone: 'Asia/Kolkata',
        hour: 'numeric',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      }) + ' IST';
    } catch (e) {
      return '8:38:00 AM IST';
    }
  };

  const [currentTimeText, setCurrentTimeText] = useState(getISTFormattedTime());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTimeText(getISTFormattedTime());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Auto GPS Location Sync on App Load
  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          let addressName = `GPS Location (${lat.toFixed(4)}°, ${lng.toFixed(4)}°)`;

          try {
            const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
            if (res.ok) {
              const data = await res.json();
              if (data && data.display_name) {
                const parts = data.display_name.split(', ');
                addressName = parts.slice(0, 3).join(', ');
              }
            }
          } catch (e) {
            console.warn('Reverse geocode error:', e);
          }

          setUserProfile((prev) => ({
            ...prev,
            currentAddress: addressName,
            currentCoordinates: { lat, lng },
          }));
          setOriginText(addressName);
          showToast(`📍 Live GPS Synced: ${addressName}`);
        },
        (err) => {
          console.warn('Geolocation sync error:', err);
        },
        { enableHighAccuracy: true, timeout: 6000 }
      );
    }
  }, []);

  // Toast Notification State
  const [alertToast, setAlertToast] = useState<string | null>(null);

  // Sync CITIES_DATA['current_location'] with userProfile coordinates and address
  useEffect(() => {
    if (userProfile.currentCoordinates) {
      CITIES_DATA['current_location'] = getCurrentLocationCityPreset(
        userProfile.currentCoordinates.lat,
        userProfile.currentCoordinates.lng,
        userProfile.currentAddress || 'MG Road Metro Station, Bengaluru, India'
      );
    }
  }, [userProfile]);

  // City change handler
  useEffect(() => {
    const preset = CITIES_DATA[cityKey] || CITIES_DATA['current_location'] || CITIES_DATA['bengaluru'];
    setRoutes(preset.sampleRoutes);
    setSelectedRoute(preset.sampleRoutes[0] || null);
    setHavens(preset.havens);
    setIncidents(preset.incidents);

    if (cityKey === 'current_location') {
      const locName = userProfile.currentAddress || 'MG Road Metro Station, Bengaluru, India';
      setOriginText(locName);
      setDestinationText('SafeHaven Emergency Center / Police Hub');
    } else if (cityKey === 'bengaluru') {
      setOriginText('MG Road Metro Station');
      setDestinationText('Indiranagar 100ft Road');
    } else if (cityKey === 'mumbai') {
      setOriginText('Bandra Railway Station');
      setDestinationText('BKC Tech Promenade');
    } else if (cityKey === 'delhi') {
      setOriginText('Rajiv Chowk Metro Gate 2');
      setDestinationText('Connaught Place Inner Circle');
    } else if (cityKey === 'hyderabad') {
      setOriginText('Raidurg Metro Station');
      setDestinationText('Cyberabad SHE Teams Hub');
    } else if (cityKey === 'san_francisco') {
      setOriginText('Mission St & 3rd St');
      setDestinationText('Powell St BART Station');
    } else if (cityKey === 'new_york') {
      setOriginText('Greenwich Village');
      setDestinationText('SoHo Central');
    }
    showToast(`📍 SafeHer Guard Hub Active: ${preset.name}`);
  }, [cityKey, userProfile]);

  // Guardian Timer Countdown Hook
  useEffect(() => {
    let interval: any = null;
    if (guardianTimer.active && guardianTimer.remainingSeconds > 0) {
      interval = setInterval(() => {
        setGuardianTimer((prev) => ({
          ...prev,
          remainingSeconds: prev.remainingSeconds - 1,
        }));
      }, 1000);
    } else if (guardianTimer.active && guardianTimer.remainingSeconds === 0) {
      // TIMER EXPIRED! Trigger automatic emergency broadcast & history log
      setGuardianTimer((prev) => ({ ...prev, active: false }));
      
      const newLog: HistoryLogEntry = {
        id: 'hist_' + Date.now(),
        type: 'timer_expired',
        title: 'Check-In Timer Expired - Alert Sent!',
        description: `User did not check in on time for ${guardianTimer.destinationName}. Emergency broadcast dispatched.`,
        timestamp: 'Just now',
        status: 'alert_sent',
        locationName: originText || 'Current GPS Position',
        recipientCount: contacts.length,
      };
      setHistoryLogs((prev) => [newLog, ...prev]);
      setIsSOSOpen(true);
      showToast('🚨 Guardian Check-In Overdue! Distress Alert sent to guardians.');
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [guardianTimer, contacts, originText]);

  const showToast = (msg: string) => {
    setAlertToast(msg);
    setTimeout(() => setAlertToast(null), 4500);
  };

  // Contacts Handlers
  const handleAddContact = (newContact: Omit<EmergencyContact, 'id'>) => {
    const created: EmergencyContact = {
      ...newContact,
      id: `c_${Date.now()}`,
    };
    setContacts((prev) => [...prev, created]);
    showToast(`Added emergency contact ${created.name}`);
  };

  const handleDeleteContact = (id: string) => {
    setContacts((prev) => prev.filter((c) => c.id !== id));
    showToast('Removed emergency contact');
  };

  const handleTogglePrimary = (id: string) => {
    setContacts((prev) =>
      prev.map((c) => ({
        ...c,
        isPrimary: c.id === id,
      }))
    );
  };

  const handleTriggerTestAlert = (contact: EmergencyContact) => {
    const locName = userProfile.currentAddress || 'MG Road Metro Station, Bengaluru, Karnataka, India';
    const gpsLink = `https://maps.google.com/?q=${userLocation.lat.toFixed(4)},${userLocation.lng.toFixed(4)}`;
    const newLog: HistoryLogEntry = {
      id: 'hist_' + Date.now(),
      type: 'sos_alert',
      title: 'Test Distress Alert',
      description: `Simulated distress broadcast sent to ${contact.name} (${contact.phone}) at ${locName}. Live GPS: ${gpsLink}`,
      timestamp: 'Just now',
      status: 'completed',
      locationName: locName,
      recipientCount: 1,
    };
    setHistoryLogs((prev) => [newLog, ...prev]);
    showToast(`🚨 Test distress alert sent to ${contact.name} (${locName})`);
  };

  // Guardian Timer Handlers
  const handleStartTimer = (minutes: number, destination: string, contactName: string) => {
    setGuardianTimer({
      active: true,
      targetMinutes: minutes,
      remainingSeconds: minutes * 60,
      destinationName: destination || 'Home',
      contactToNotify: contactName,
      startedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    });
    showToast(`Guardian Check-In started for ${minutes} mins`);
  };

  const handleCheckInSafe = () => {
    setGuardianTimer((prev) => ({ ...prev, active: false }));
    const newLog: HistoryLogEntry = {
      id: 'hist_' + Date.now(),
      type: 'check_in',
      title: 'Checked In Safe',
      description: `User checked in safely at ${guardianTimer.destinationName}. Guardians notified.`,
      timestamp: 'Just now',
      status: 'completed',
      locationName: guardianTimer.destinationName,
      recipientCount: contacts.length,
    };
    setHistoryLogs((prev) => [newLog, ...prev]);
    showToast('✅ Checked In Safe! Guardians notified of safe arrival.');
  };

  const handleExtendTimer = (extraMinutes: number) => {
    setGuardianTimer((prev) => ({
      ...prev,
      remainingSeconds: prev.remainingSeconds + extraMinutes * 60,
    }));
    showToast(`Timer extended by +${extraMinutes} mins`);
  };

  const handleCancelTimer = () => {
    setGuardianTimer((prev) => ({ ...prev, active: false }));
    showToast('Check-In timer cancelled.');
  };

  // Emergency SOS History Logger
  const handleLogSOSHistory = (recipientNames: string[]) => {
    const newLog: HistoryLogEntry = {
      id: 'hist_' + Date.now(),
      type: 'sos_alert',
      title: 'Emergency SOS Signal Triggered',
      description: `Distress beacon & live GPS broadcast sent to ${recipientNames.join(', ')}.`,
      timestamp: 'Just now',
      status: 'alert_sent',
      locationName: '37.7749° N, 122.4194° W',
      recipientCount: recipientNames.length,
    };
    setHistoryLogs((prev) => [newLog, ...prev]);
  };

  // Fake Call Logger
  const handleLogFakeCallHistory = (callerName: string) => {
    const newLog: HistoryLogEntry = {
      id: 'hist_' + Date.now(),
      type: 'fake_call',
      title: 'Fake Call Triggered',
      description: `Simulated incoming call from "${callerName}" to deter uncomfortable approach.`,
      timestamp: 'Just now',
      status: 'completed',
      locationName: 'Current Location',
    };
    setHistoryLogs((prev) => [newLog, ...prev]);
    showToast(`Simulated incoming call from ${callerName}`);
  };

  // AI Route Assessment & Route Calculation Handler
  const handleRunAIAssessment = async () => {
    setIsAnalyzingAI(true);

    const orig = originText.trim() || 'Origin Location';
    const dest = destinationText.trim() || 'Destination Point';

    // Update candidate routes to match requested origin & destination
    const updatedRoutes: SafeRouteOption[] = activeCity.sampleRoutes.map((r) => {
      if (r.type === 'safest') {
        const updatedSegments = r.segments.map((seg, idx) => {
          if (idx === 0) return { ...seg, instruction: `Depart from ${orig} along well-lit corridor` };
          if (idx === r.segments.length - 1) return { ...seg, instruction: `Arrive safely at ${dest}` };
          return seg;
        });
        return {
          ...r,
          name: `SafePath Corridor (${orig} ➔ ${dest})`,
          summary: `Primary verified safe path from ${orig} to ${dest}. Passes active 24/7 SafeHavens with 98% streetlight coverage.`,
          segments: updatedSegments,
        };
      } else if (r.type === 'well_lit') {
        return {
          ...r,
          name: `Max Lighting Path (${orig} ➔ ${dest})`,
          summary: `Maximum streetlight density route between ${orig} and ${dest}.`,
        };
      } else {
        return {
          ...r,
          name: `Direct Transit Route (${orig} ➔ ${dest})`,
          summary: `Fastest direct path between ${orig} and ${dest}.`,
        };
      }
    });

    setRoutes(updatedRoutes);

    // Auto select top safest route and plot on map
    const topSafest = updatedRoutes.find((r) => r.type === 'safest') || updatedRoutes[0];
    setSelectedRoute(topSafest);

    try {
      const res = await fetch('/api/route-safety-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: orig,
          destination: dest,
          timeOfDay: `Morning (${currentTimeText})`,
          travelMode,
          candidateRoutes: updatedRoutes,
        }),
      });

      const data = await res.json();
      setAiAnalysisResult(data);
      
      if (data && typeof data.safetyScore === 'number') {
        setSelectedRoute((prev) => prev ? ({ ...prev, safetyScore: data.safetyScore }) : topSafest);
      }

      // Log to history
      const newLog: HistoryLogEntry = {
        id: 'hist_' + Date.now(),
        type: 'ai_audit',
        title: 'Gemini AI Route Audit',
        description: `Safer route calculated for ${orig} → ${dest}. Safety Score: ${data.safetyScore || 94}/100. ${data.summary}`,
        timestamp: 'Just now',
        status: 'completed',
        locationName: `${orig} → ${dest}`,
      };
      setHistoryLogs((prev) => [newLog, ...prev]);
      showToast(`🗺️ Safer Route Plotted on Map: ${orig} ➔ ${dest}`);
    } catch (err) {
      setAiAnalysisResult({
        safetyScore: 94,
        summary: `AI Route Audit: Standard Safe Corridor verified between ${orig} and ${dest} with 98% streetlight coverage.`,
        precautions: [
          `Stick to main sidewalk departing from ${orig}`,
          `Use 24/7 open stores as safe haven checkpoints before ${dest}`,
        ],
      });
      showToast(`🗺️ Safer Route Plotted on Map: ${orig} ➔ ${dest}`);
    } finally {
      setIsAnalyzingAI(false);
    }
  };

  const handleAddIncident = (newIncident: CommunityIncident) => {
    setIncidents((prev) => [newIncident, ...prev]);
    
    const newLog: HistoryLogEntry = {
      id: 'hist_' + Date.now(),
      type: 'incident_report',
      title: `Reported: ${newIncident.title}`,
      description: newIncident.description,
      timestamp: 'Just now',
      status: 'completed',
      locationName: newIncident.address,
    };
    setHistoryLogs((prev) => [newLog, ...prev]);
    showToast('Published community hazard to SafeHer Guard Map');
  };

  const handleSimulateNewCheckIn = () => {
    handleStartTimer(10, 'Powell St Station', contacts[0]?.name || 'Guardian Circle');
    setIsHistoryOpen(false);
  };

  const handleClearHistory = () => {
    setHistoryLogs([]);
    showToast('Activity history cleared.');
  };

  const userLocation: LocationCoordinates = userProfile.currentCoordinates || {
    lat: activeCity.center.lat + 0.002,
    lng: activeCity.center.lng - 0.003,
  };

  const primaryContact = contacts.find((c) => c.isPrimary) || contacts[0];

  return (
    <div className="min-h-screen bg-[#0A0C10] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      
      {/* Header Navigation */}
      <HeaderNavbar
        cityKey={cityKey}
        currentCityName={activeCity.name}
        userCurrentLocation={userProfile.currentAddress || originText || activeCity.name}
        onCityChange={(key) => setCityKey(key)}
        onOpenSOS={() => setIsSOSOpen(true)}
        onOpenFakeCall={() => setIsFakeCallOpen(true)}
        onOpenAIChat={() => setIsAIChatOpen(true)}
        onOpenReportModal={() => setIsReportOpen(true)}
        onOpenInsightsModal={() => setIsInsightsOpen(true)}
        onOpenContactsModal={() => setIsContactsOpen(true)}
        onOpenHistoryModal={() => setIsHistoryOpen(true)}
        onOpenProfileModal={() => setIsProfileOpen(true)}
        activeGuardianMinutes={
          guardianTimer.active ? Math.ceil(guardianTimer.remainingSeconds / 60) : null
        }
        historyCount={historyLogs.length}
        userName={userProfile.name}
      />

      {/* Alert Toast Notification Banner */}
      {alertToast && (
        <div className="fixed top-16 right-4 z-40 bg-emerald-500 text-slate-950 px-4 py-2.5 rounded-2xl shadow-2xl font-bold text-xs flex items-center gap-2 animate-bounce border border-white/20">
          <ShieldCheck className="w-4 h-4" />
          <span>{alertToast}</span>
        </div>
      )}

      {/* Main Dashboard - Pure Bento Grid Theme Layout */}
      <main className="flex-1 max-w-[1360px] w-full mx-auto p-4 sm:p-6 space-y-4">
        
        {/* Top Header Banner Info */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#161B22] border border-slate-800 rounded-3xl p-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-900/30 shrink-0">
              <ShieldAlert className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                SafeHer<span className="text-emerald-500"> Guard</span>
              </h1>
              <p className="text-xs text-slate-400">AI-Guided Safe Walking Navigation & Guardian Security Network</p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-[#0A0C10] border border-emerald-500/30 rounded-full px-4 py-2 text-xs shadow-md">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse shadow-sm shadow-emerald-400" />
              <span className="font-bold text-emerald-300 uppercase tracking-widest text-[10px] flex items-center gap-1">
                <span>🇮🇳 IST Mesh System Active</span>
              </span>
            </div>
            <div className="h-4 w-px bg-slate-800" />
            <span className="font-mono font-bold text-slate-100">{currentTimeText}</span>
          </div>
        </div>

        {/* Home Screen Mini Safety Widget Dock */}
        <MiniHomeScreenWidget
          onOpenSOS={() => setIsSOSOpen(true)}
          onOpenFakeCall={() => setIsFakeCallOpen(true)}
          onOpenAIChat={() => setIsAIChatOpen(true)}
          onQuickStartTimer={(mins) => handleStartTimer(mins, destinationText || 'Home', contacts[0]?.name || 'Guardians')}
          onCheckInSafe={handleCheckInSafe}
          activeTimerMinutes={guardianTimer.active ? Math.ceil(guardianTimer.remainingSeconds / 60) : null}
          activeRouteName={selectedRoute?.name || 'Market St Corridor'}
          safetyScore={selectedRoute?.safetyScore || 94}
          nearestHavenName={havens[0]?.name || 'Walgreens 24/7'}
          cityName={activeCity.name}
        />

        {/* Split 2-Screen Grid Layout (Left Screen & Right Screen) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          
          {/* ==================== LEFT SCREEN: NAVIGATION & INTERACTIVE MAP ==================== */}
          <div className="lg:col-span-7 space-y-4">
            
            {/* Left Screen Label Header */}
            <div className="bg-[#161B22] border border-slate-800/90 rounded-2xl px-4 py-2.5 flex items-center justify-between text-xs shadow-md">
              <div className="flex items-center gap-2 font-bold text-slate-200">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse" />
                <span className="uppercase tracking-wider text-[11px] text-blue-400">Left Screen</span>
                <span className="text-slate-500">•</span>
                <span>Safe Route Navigation & Live Map Visualizer</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Screen 1 of 2</span>
            </div>

            {/* Left Screen Item 1: Live Interactive Map View */}
            <div className="bg-[#161B22] border border-slate-800 rounded-3xl overflow-hidden relative group min-h-[460px] flex flex-col shadow-2xl">
              <MapContainer
                center={activeCity.center}
                zoom={activeCity.zoom}
                selectedRoute={selectedRoute}
                allRoutes={routes}
                havens={havens}
                incidents={incidents}
                userLocation={userLocation}
                onSelectHaven={(h) => showToast(`SafeHaven: ${h.name} (24/7 Verified)`)}
                onSelectIncident={(i) => showToast(`Hazard Alert: ${i.title}`)}
                showLightingHeatmap={showLightingHeatmap}
                onToggleLightingHeatmap={() => setShowLightingHeatmap(!showLightingHeatmap)}
              />
            </div>

            {/* Left Screen Item 2: Route Safety Planner & Navigation Panel */}
            <NavigationPanel
              routes={routes}
              selectedRoute={selectedRoute}
              onSelectRoute={(r) => setSelectedRoute(r)}
              travelMode={travelMode}
              onTravelModeChange={(m) => setTravelMode(m)}
              originText={originText}
              setOriginText={setOriginText}
              destinationText={destinationText}
              setDestinationText={setDestinationText}
              onRunAIAssessment={handleRunAIAssessment}
              isAnalyzingAI={isAnalyzingAI}
              aiAnalysisResult={aiAnalysisResult}
              userProfile={userProfile}
              onOpenShareProgressModal={() => setIsShareProgressOpen(true)}
            />
          </div>

          {/* ==================== RIGHT SCREEN: GUARDIAN SECURITY & CONTROL CENTER ==================== */}
          <div className="lg:col-span-5 space-y-4 flex flex-col">
            
            {/* Right Screen Label Header */}
            <div className="bg-[#161B22] border border-slate-800/90 rounded-2xl px-4 py-2.5 flex items-center justify-between text-xs shadow-md">
              <div className="flex items-center gap-2 font-bold text-slate-200">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="uppercase tracking-wider text-[11px] text-emerald-400">Right Screen</span>
                <span className="text-slate-500">•</span>
                <span>Guardian Security & Live Control Center</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">Screen 2 of 2</span>
            </div>

            {/* Right Screen Item 1: Share Live Progress Feature Card */}
            <div className="bg-gradient-to-br from-[#161B22] via-[#0D1117] to-teal-950/20 border-2 border-teal-500/40 hover:border-teal-400 rounded-3xl p-5 shadow-2xl space-y-3 transition-all">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black text-lg shadow-lg shadow-emerald-500/20">
                    <Share2 className="w-5 h-5 text-slate-950" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white flex items-center gap-2">
                      Share Live Progress
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                        Temporary Link
                      </span>
                    </h3>
                    <p className="text-[11px] text-slate-400">Send encrypted live location & ETA to guardians</p>
                  </div>
                </div>

                <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
              </div>

              <div className="bg-[#0A0C10] p-3 rounded-2xl border border-slate-800 text-xs space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Active Route:</span>
                  <span className="font-bold text-emerald-300">{selectedRoute?.name || 'Market St Corridor'}</span>
                </div>
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Destination:</span>
                  <span className="font-bold text-slate-200 truncate max-w-[180px]">{destinationText || 'Market St'}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-800/80">
                  <span className="text-slate-400">Recipient Guardians:</span>
                  <span className="font-bold text-cyan-400">{contacts.length} Connected</span>
                </div>
              </div>

              <button
                onClick={() => setIsShareProgressOpen(true)}
                className="w-full py-2.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                <span>Generate & Send Temporary Progress Link</span>
              </button>
            </div>

            {/* Right Screen Item 2: Critical Emergency SOS Button */}
            <div
              onClick={() => setIsSOSOpen(true)}
              className="bg-rose-600/10 border-2 border-rose-500/30 hover:border-rose-500 rounded-3xl p-5 flex flex-col items-center justify-center text-center cursor-pointer transition-all shadow-xl group hover:bg-rose-600/15"
            >
              <div className="w-16 h-16 bg-rose-600 group-hover:bg-rose-500 rounded-full flex items-center justify-center mb-2 shadow-2xl shadow-rose-900/60 transition-transform group-hover:scale-105 active:scale-95">
                <span className="text-xl font-black italic text-white tracking-widest">SOS</span>
              </div>
              <h3 className="text-sm font-bold text-rose-100 mb-0.5">Emergency Distress Trigger</h3>
              <p className="text-[11px] text-rose-200/70">Instantly broadcast live location to {contacts.length} guardians</p>
            </div>

            {/* Right Screen Item 3: Guardian Check-In Timer Card */}
            <CheckInTimerCard
              timerState={guardianTimer}
              onStartTimer={handleStartTimer}
              onCheckInSafe={handleCheckInSafe}
              onExtendTimer={handleExtendTimer}
              onCancelTimer={handleCancelTimer}
              primaryContact={primaryContact}
              contacts={contacts}
            />

            {/* Right Screen Item 4: Voice AI Assistant Control Engine */}
            <VoiceAIWidget
              activeRouteName={selectedRoute?.name || 'SF Safe Corridor'}
              safetyScore={selectedRoute?.safetyScore || 94}
              onSpeechInput={(spokenText) => {
                showToast(`Voice AI heard: "${spokenText}"`);
                setDestinationText(spokenText);
              }}
              onAnnounceRoute={() => {
                if (selectedRoute) {
                  voiceAI.speak(
                    `Announcing current route: ${selectedRoute.name}. Distance is ${selectedRoute.distanceKm} kilometers, with ${selectedRoute.lightingScore} percent streetlight visibility and ${selectedRoute.openHavensCount} active SafeHavens along your path.`
                  );
                }
              }}
              onAnnounceSafetyStatus={() => {
                voiceAI.speak(
                  `Real-time safety update for ${activeCity.name}. Safety mesh active. Streetlight coverage is 98 percent. All ${contacts.length} guardians are online.`
                );
              }}
            />

            {/* Right Screen Item 5: Trusted Circle (Guardians) */}
            <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-5 shadow-xl flex-1 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Trusted Circle</h3>
                <button
                  onClick={() => setIsContactsOpen(true)}
                  className="text-xs text-blue-400 font-bold hover:underline cursor-pointer"
                >
                  Manage ({contacts.length})
                </button>
              </div>

              {/* Contact Avatars Grid */}
              <div className="grid grid-cols-4 gap-3">
                {contacts.slice(0, 3).map((c) => (
                  <div key={c.id} className="flex flex-col items-center gap-1.5 text-center">
                    <div className="relative">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm ring-2 ring-emerald-500 ring-offset-2 ring-offset-[#161B22] shadow-md">
                        {c.name.charAt(0)}
                      </div>
                      <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-[#161B22]" />
                    </div>
                    <p className="text-[11px] font-semibold text-slate-200 truncate w-full">{c.name.split(' ')[0]}</p>
                  </div>
                ))}

                {/* Add New Contact Button */}
                <div
                  onClick={() => setIsContactsOpen(true)}
                  className="flex flex-col items-center justify-center cursor-pointer group"
                >
                  <div className="w-12 h-12 rounded-2xl border-2 border-dashed border-slate-700 hover:border-blue-500 flex items-center justify-center transition-colors">
                    <Plus className="w-4 h-4 text-slate-500 group-hover:text-blue-400" />
                  </div>
                  <p className="text-[10px] mt-1 font-bold text-slate-500 uppercase tracking-tighter">Add Guardian</p>
                </div>
              </div>

              <button
                onClick={() => setIsContactsOpen(true)}
                className="mt-4 w-full py-2.5 rounded-2xl bg-blue-600/10 hover:bg-blue-600/20 text-blue-300 font-bold text-xs border border-blue-500/30 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Test Emergency Broadcast</span>
              </button>
            </div>

            {/* Right Screen Item 6: Journey Summary & Path Visibility Stats */}
            <div className="bg-[#161B22] border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Path Telemetry & Stats</h3>
              
              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between mb-1 font-semibold">
                    <span className="text-slate-400">Path Streetlight Visibility</span>
                    <span className="text-emerald-400 font-bold">98%</span>
                  </div>
                  <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div className="bg-emerald-500 h-full w-[98%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1 font-semibold">
                    <span className="text-slate-400">Device Battery Backup</span>
                    <span className="text-blue-400 font-bold">84%</span>
                  </div>
                  <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div className="bg-blue-500 h-full w-[84%]" />
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5 text-indigo-400" /> Monitored by CCTV: 85%
                </span>
                <span className="text-emerald-400 font-semibold">CCTV Active</span>
              </div>
            </div>

          </div>

          {/* Bottom Row (12 Cols): Activity History Stream Widget */}
          <div className="lg:col-span-12 bg-[#161B22] border border-slate-800 rounded-3xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-blue-400" />
                <h3 className="font-heading font-bold text-sm text-white">Recent Safety Activity History</h3>
              </div>
              <button
                onClick={() => setIsHistoryOpen(true)}
                className="text-xs font-bold text-blue-400 hover:underline cursor-pointer flex items-center gap-1"
              >
                View Full Timeline ({historyLogs.length}) →
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {historyLogs.slice(0, 3).map((log) => (
                <div
                  key={log.id}
                  onClick={() => setIsHistoryOpen(true)}
                  className="bg-[#0A0C10] border border-slate-800 hover:border-slate-700 p-3.5 rounded-2xl flex flex-col justify-between gap-2 transition-all cursor-pointer"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-xs text-white truncate">{log.title}</span>
                      <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full border border-slate-700">
                        {log.timestamp}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{log.description}</p>
                  </div>
                  {log.locationName && (
                    <span className="text-[10px] text-blue-400 flex items-center gap-1 pt-1 border-t border-slate-800/80">
                      <MapPin className="w-3 h-3" /> {log.locationName}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>
      </main>

      {/* Modals & Drawers */}
      <ContactsModal
        isOpen={isContactsOpen}
        onClose={() => setIsContactsOpen(false)}
        contacts={contacts}
        onAddContact={handleAddContact}
        onDeleteContact={handleDeleteContact}
        onTogglePrimary={handleTogglePrimary}
        onTriggerTestAlert={handleTriggerTestAlert}
      />

      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        historyLogs={historyLogs}
        onClearHistory={handleClearHistory}
        onSimulateNewCheckIn={handleSimulateNewCheckIn}
      />

      <EmergencySOSModal
        isOpen={isSOSOpen}
        onClose={() => setIsSOSOpen(false)}
        userLocation={userLocation}
        contacts={contacts}
        onLogSOSHistory={handleLogSOSHistory}
      />

      <FakeCallModal
        isOpen={isFakeCallOpen}
        onClose={() => setIsFakeCallOpen(false)}
        onLogHistory={handleLogFakeCallHistory}
      />

      <AIChatDrawer
        isOpen={isAIChatOpen}
        onClose={() => setIsAIChatOpen(false)}
        currentLocationName={activeCity.name}
      />

      <InsightsModal
        isOpen={isInsightsOpen}
        onClose={() => setIsInsightsOpen(false)}
        neighborhoods={activeCity.neighborhoods}
      />

      <ReportIncidentModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        onAddIncident={handleAddIncident}
      />

      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        userProfile={userProfile}
        onSaveProfile={(updated) => {
          setUserProfile(updated);
          showToast(`Profile & Location updated for ${updated.name}`);
        }}
        onSetLocationAsOrigin={(addr) => {
          if (addr) {
            setOriginText(addr);
            showToast(`Origin set to: ${addr}`);
          }
        }}
        onSetLocationAsDestination={(addr) => {
          if (addr) {
            setDestinationText(addr);
            showToast(`Destination set to: ${addr}`);
          }
        }}
      />

      <ShareLiveProgressModal
        isOpen={isShareProgressOpen}
        onClose={() => setIsShareProgressOpen(false)}
        selectedRoute={selectedRoute}
        contacts={contacts}
        userProfile={userProfile}
        originText={originText}
        destinationText={destinationText}
        onSendToast={showToast}
      />

      {/* Sub-footer Info */}
      <footer className="mt-8 border-t border-slate-800 bg-[#0A0C10] px-6 py-4">
        <div className="max-w-[1360px] mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex gap-6 text-[10px] text-slate-500 uppercase font-bold tracking-widest">
            <span className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-blue-500" /> Network Stable</span>
            <span className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> GPS Locked</span>
            <span className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Guardian Mesh Ready</span>
          </div>
          <p className="text-[10px] text-slate-600 uppercase font-bold tracking-widest">© 2026 SafeHer Guard Security Systems</p>
        </div>
      </footer>

    </div>
  );
}
