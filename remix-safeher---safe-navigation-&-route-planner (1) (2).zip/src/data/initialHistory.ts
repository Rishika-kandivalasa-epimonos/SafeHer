import { HistoryLogEntry } from '../types';

export const INITIAL_HISTORY: HistoryLogEntry[] = [
  {
    id: 'hist_1',
    type: 'check_in',
    title: 'Check-in Completed Safe',
    description: 'Arrived safely at Indiranagar 100ft Road Metro Station after 14 min walk.',
    timestamp: 'Today at 10:14 PM',
    status: 'completed',
    locationName: 'Indiranagar 100ft Road, Bengaluru, India',
    recipientCount: 2,
    metadata: { routeTaken: 'SafeHer Corridor (MG Road to Indiranagar)', durationMinutes: 14 }
  },
  {
    id: 'hist_2',
    type: 'ai_audit',
    title: 'Gemini AI Route Audit',
    description: 'Generated safety assessment for MG Road to Indiranagar. Score: 94/100.',
    timestamp: 'Today at 9:58 PM',
    status: 'completed',
    locationName: 'MG Road Metro Station, Bengaluru, India',
    metadata: { score: 94, lighting: '98% High Streetlight' }
  },
  {
    id: 'hist_3',
    type: 'fake_call',
    title: 'Fake Call Simulated',
    description: 'Triggered simulated incoming call from "Mom" to deter unwanted approach.',
    timestamp: 'Yesterday at 11:30 PM',
    status: 'completed',
    locationName: 'Koramangala 5th Block, Bengaluru, India',
    metadata: { caller: 'Mom', durationSeconds: 45 }
  },
  {
    id: 'hist_4',
    type: 'incident_report',
    title: 'Community Hazard Reported',
    description: 'Reported broken street lamp creating dark zone near Metro pillar #140.',
    timestamp: '2 days ago at 8:15 PM',
    status: 'completed',
    locationName: 'Indiranagar Metro Junction, Bengaluru, India',
    metadata: { category: 'poor_lighting', severity: 'medium', upvotes: 14 }
  },
  {
    id: 'hist_5',
    type: 'sos_alert',
    title: 'Test SOS Broadcast',
    description: 'Simulated distress alert sent to 3 emergency contacts with live India GPS coordinates.',
    timestamp: '3 days ago at 4:20 PM',
    status: 'alert_sent',
    locationName: 'MG Road, Bengaluru, Karnataka, India',
    recipientCount: 3,
    metadata: { contactsAlerted: ['Mom', 'Alex (Roommate)', 'Marcus'] }
  }
];
