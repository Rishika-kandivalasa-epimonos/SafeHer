// Voice AI Speech Synthesis & Voice Recognition Helper Utilities

export interface SpeechSettings {
  rate: number;
  pitch: number;
  volume: number;
  voiceIndex: number;
  autoReadAI: boolean;
}

export const DEFAULT_SPEECH_SETTINGS: SpeechSettings = {
  rate: 1.0,
  pitch: 1.0,
  volume: 1.0,
  voiceIndex: 0,
  autoReadAI: true,
};

// Singleton Speech Manager
class VoiceAIEngine {
  private synth: SpeechSynthesis | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSpeaking: boolean = false;
  private settings: SpeechSettings = DEFAULT_SPEECH_SETTINGS;
  private listeners: Set<(speaking: boolean, text?: string) => void> = new Set();

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  private loadVoices() {
    if (!this.synth) return;
    this.voices = this.synth.getVoices().filter((v) => v.lang.startsWith('en'));
  }

  public getAvailableVoices(): SpeechSynthesisVoice[] {
    if (!this.voices.length && this.synth) {
      this.loadVoices();
    }
    return this.voices;
  }

  public subscribe(listener: (speaking: boolean, text?: string) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(speaking: boolean, text?: string) {
    this.isSpeaking = speaking;
    this.listeners.forEach((l) => l(speaking, text));
  }

  public speak(text: string, customSettings?: Partial<SpeechSettings>): Promise<void> {
    return new Promise((resolve) => {
      if (!this.synth) {
        console.warn('Speech synthesis not supported in this browser environment.');
        resolve();
        return;
      }

      this.stop();

      // Clean markdown symbols or asterisks from text for smooth speech
      const cleanText = text
        .replace(/[*_#~`]/g, '')
        .replace(/https?:\/\/\S+/g, 'link')
        .trim();

      if (!cleanText) {
        resolve();
        return;
      }

      const utterance = new SpeechSynthesisUtterance(cleanText);
      const activeSettings = { ...this.settings, ...customSettings };

      utterance.rate = activeSettings.rate;
      utterance.pitch = activeSettings.pitch;
      utterance.volume = activeSettings.volume;

      const availableVoices = this.getAvailableVoices();
      if (availableVoices.length > 0) {
        const preferredVoice = availableVoices[activeSettings.voiceIndex] || availableVoices[0];
        utterance.voice = preferredVoice;
      }

      utterance.onstart = () => {
        this.notify(true, cleanText);
      };

      utterance.onend = () => {
        this.notify(false);
        resolve();
      };

      utterance.onerror = (e) => {
        console.warn('Speech synthesis error:', e);
        this.notify(false);
        resolve();
      };

      this.currentUtterance = utterance;
      this.synth.speak(utterance);
    });
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
      this.notify(false);
    }
  }

  public getIsSpeaking(): boolean {
    return this.isSpeaking;
  }
}

export const voiceAI = new VoiceAIEngine();

// Helper for Browser Speech-to-Text Recognition
export const createSpeechRecognizer = (
  onResult: (text: string) => void,
  onEnd?: () => void,
  onError?: (err: any) => void
) => {
  if (typeof window === 'undefined') return null;

  const SpeechRecognition =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) {
    console.warn('Speech recognition API not supported in this browser.');
    return null;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = 'en-US';

  recognition.onresult = (event: any) => {
    let transcript = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      transcript += event.results[i][0].transcript;
    }
    onResult(transcript);
  };

  recognition.onend = () => {
    if (onEnd) onEnd();
  };

  recognition.onerror = (event: any) => {
    if (onError) onError(event.error);
  };

  return recognition;
};
