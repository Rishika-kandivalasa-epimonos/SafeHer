// Web Audio API helper for emergency alarm siren and phone ringtone synthesizer

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

let sirenOscillator1: OscillatorNode | null = null;
let sirenOscillator2: OscillatorNode | null = null;
let sirenGain: GainNode | null = null;
let sirenTimer: any = null;

export function startEmergencySiren() {
  stopEmergencySiren();
  try {
    const ctx = getAudioContext();
    sirenGain = ctx.createGain();
    sirenGain.gain.setValueAtTime(0.3, ctx.currentTime);

    sirenOscillator1 = ctx.createOscillator();
    sirenOscillator1.type = 'sawtooth';
    
    sirenOscillator2 = ctx.createOscillator();
    sirenOscillator2.type = 'sine';

    sirenOscillator1.connect(sirenGain);
    sirenOscillator2.connect(sirenGain);
    sirenGain.connect(ctx.destination);

    sirenOscillator1.start();
    sirenOscillator2.start();

    let high = false;
    sirenTimer = setInterval(() => {
      if (!audioCtx || !sirenOscillator1 || !sirenOscillator2) return;
      const targetFreq1 = high ? 960 : 600;
      const targetFreq2 = high ? 1200 : 750;
      sirenOscillator1.frequency.exponentialRampToValueAtTime(targetFreq1, audioCtx.currentTime + 0.25);
      sirenOscillator2.frequency.exponentialRampToValueAtTime(targetFreq2, audioCtx.currentTime + 0.25);
      high = !high;
    }, 300);
  } catch (err) {
    console.error('Failed to start audio siren:', err);
  }
}

export function stopEmergencySiren() {
  if (sirenTimer) {
    clearInterval(sirenTimer);
    sirenTimer = null;
  }
  if (sirenOscillator1) {
    try { sirenOscillator1.stop(); sirenOscillator1.disconnect(); } catch (e) {}
    sirenOscillator1 = null;
  }
  if (sirenOscillator2) {
    try { sirenOscillator2.stop(); sirenOscillator2.disconnect(); } catch (e) {}
    sirenOscillator2 = null;
  }
  if (sirenGain) {
    try { sirenGain.disconnect(); } catch (e) {}
    sirenGain = null;
  }
}

let ringTimer: any = null;

export function startPhoneRingtone() {
  stopPhoneRingtone();
  try {
    const ctx = getAudioContext();
    const playPulse = () => {
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.frequency.value = 440; // A4
      osc2.frequency.value = 480;

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.8);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start();
      osc2.start();
      osc1.stop(ctx.currentTime + 1.8);
      osc2.stop(ctx.currentTime + 1.8);
    };

    playPulse();
    ringTimer = setInterval(playPulse, 3000);
  } catch (e) {
    console.error('Failed to play ringtone:', e);
  }
}

export function stopPhoneRingtone() {
  if (ringTimer) {
    clearInterval(ringTimer);
    ringTimer = null;
  }
}
