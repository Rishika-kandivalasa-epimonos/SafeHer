export type TravelMode = 'walking' | 'biking' | 'scooter' | 'night_walk';

export interface LocationCoordinates {
  lat: number;
  lng: number;
}

export interface RouteSegment {
  instruction: string;
  distanceMeters: number;
  lightingQuality: 'high' | 'medium' | 'low';
  monitoredByCCTV: boolean;
  pedestrianDensity: 'high' | 'moderate' | 'low';
  riskScore: number; // 0 to 100 (100 is safest)
  coordinates: LocationCoordinates[];
}

export interface SafeRouteOption {
  id: string;
  name: string;
  tagline: string;
  type: 'safest' | 'fastest' | 'balanced' | 'well_lit';
  safetyScore: number; // 0 - 100
  distanceKm: number;
  estimatedMinutes: number;
  lightingScore: number; // percentage well lit
  cctvCoverage: number; // percentage monitored
  openHavensCount: number;
  riskPointsCount: number;
  pathCoordinates: LocationCoordinates[];
  segments: RouteSegment[];
  summary: string;
  precautions: string[];
}

export type HavenType = 'police' | 'hospital' | 'store_247' | 'open_cafe' | 'transit_hub' | 'emergency_call_box';

export interface SafeHaven {
  id: string;
  name: string;
  type: HavenType;
  address: string;
  isOpen24Hours: boolean;
  distanceMeters: number;
  coordinates: LocationCoordinates;
  phone?: string;
  verifiedStatus: 'verified' | 'community_verified';
}

export type IncidentCategory = 'poor_lighting' | 'suspicious_activity' | 'harassment' | 'broken_infrastructure' | 'road_closure' | 'crowded_event' | 'police_presence';

export interface CommunityIncident {
  id: string;
  title: string;
  category: IncidentCategory;
  description: string;
  coordinates: LocationCoordinates;
  address: string;
  timestamp: string;
  upvotes: number;
  verifiedByCommunity: boolean;
  severity: 'low' | 'medium' | 'high' | 'critical';
  userReported?: boolean;
}

export interface NeighborhoodSafetyProfile {
  name: string;
  city: string;
  overallSafetyIndex: number; // 0 - 100
  lightingIndex: number;
  crimeRateCategory: 'Very Low' | 'Low' | 'Moderate' | 'Elevated';
  safeHours: string;
  activeHavensCount: number;
  topPrecautions: string[];
}

export interface EmergencyContact {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  isPrimary: boolean;
}

export interface FakeCallPreset {
  id: string;
  callerName: string;
  callerNumber: string;
  callerAvatarUrl?: string;
  scriptPrompt: string;
}

export interface GuardianTimer {
  active: boolean;
  targetMinutes: number;
  remainingSeconds: number;
  destinationName: string;
  contactToNotify: string;
  startedAt?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  bloodType: string;
  medicalNotes: string;
  emergencyInfo: string;
  homeAddress: string;
  homeCoordinates?: LocationCoordinates;
  workAddress: string;
  workCoordinates?: LocationCoordinates;
  currentAddress: string;
  currentCoordinates: LocationCoordinates;
  preferredTravelMode: TravelMode;
  autoVoiceNav: boolean;
  shareLiveLocationWithGuardians: boolean;
  avatarUrl?: string;
}

export type HistoryType = 'check_in' | 'sos_alert' | 'timer_expired' | 'fake_call' | 'incident_report' | 'ai_audit';

export interface HistoryLogEntry {
  id: string;
  type: HistoryType;
  title: string;
  description: string;
  timestamp: string;
  status: 'completed' | 'alert_sent' | 'cancelled' | 'resolved';
  locationName?: string;
  recipientCount?: number;
  metadata?: Record<string, any>;
}

